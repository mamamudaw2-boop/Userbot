import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "200"))

DEVS = list(map(int, os.getenv("DEVS", "2010120067").split()))

API_ID = int(os.getenv("API_ID", "33366894"))

API_HASH = os.getenv("API_HASH", "d25a099e762e9bad00a6c7b602aa9dc7")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8774310125:AAG_P21H_-LrvlheG6OcTCc5k4mWjpdlJn0")

OWNER_ID = int(os.getenv("OWNER_ID", "2010120067"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-10031517641").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://hadzzz:<db_password>@cluster0.pixhojk.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003915356236"))
