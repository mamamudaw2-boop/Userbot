process.on('unhandledRejection', () => {});
process.on('uncaughtException', () => {});
process.on('warning', () => {});
console.error = () => {};
console.warn = () => {};
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const os = require('os');
const axios = require("axios");
const chalk = require("chalk");
const fetch = require("node-fetch");
const path = require('path');
const CryptoJS = require('crypto-js');

const userSearchSessions = {};
const userBlacklistSessions = {};
const userPremiumSessions = {};
const ownerManagementSessions = {};
const ceoManagementSessions = {};
const rewardSessions = {};
const chatSessions = {}; 
const lastMenuMessage = {};
const activeMenus = {};
const autoForwards = {}; 
const depositSessions = {};

const DATA_FILE = 'data.json';
const PRODUCT_FILE = 'dataproduct.json';
const { 
BOT_TOKEN, 
OWNER_IDS, 
PAYMENT_SETTINGS, 
CHANNEL_USERNAME, 
DEVELOPER, 
MENU_IMAGES } = require('./config.js');

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const BOT_START_TIME = Date.now();
const defaultData = {
  premium: {},
  owner: OWNER_IDS,
  groups: [],
  users: [],
  blacklist: []
};

const getUptime = () => {
  const uptimeSeconds = process.uptime();
  const hours = Math.floor(uptimeSeconds / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeSeconds % 60);

  return `${hours}h ${minutes}m ${seconds}s`;
};

function getRandomImage() {
  return MENU_IMAGES[Math.floor(Math.random() * MENU_IMAGES.length)];
}

function loadJSON(file) {
  try {
    if (!fs.existsSync(file)) fs.writeFileSync(file, '{}');
    const raw = fs.readFileSync(file, 'utf8');
    return raw.length ? JSON.parse(raw) : {};
  } catch (e) {
    console.error('loadJSON error:', e);
    return {};
  }
}

function saveJSON(file, data) {
  try {
    if (!data) data = {};
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error('saveJSON error:', e);
  }
}

const users = loadJSON(DATA_FILE);
const productDB = loadJSON(PRODUCT_FILE);

if (!productDB.products) productDB.products = {};
if (!productDB.orders) productDB.orders = {};
if (!productDB.deposits) productDB.deposits = {};
if (!productDB.users) productDB.users = {};

function saveData() { saveJSON(DATA_FILE, users); }
function saveProductData() { saveJSON(PRODUCT_FILE, productDB); } 

function initializeUser(userId, user = {}) {
  if (!productDB.users) productDB.users = {};
  if (!productDB.users[userId]) {
    productDB.users[userId] = {
      id: userId,
      name: user.first_name || 'User',
      balance: 0,
      created_at: new Date().toISOString()
    };
    saveProductData(); 
  }
  return productDB.users[userId];
}

function calculateAdminFee(amount) {
  const fixed = PAYMENT_SETTINGS.ADMIN_FEE.FIXED || 0;
  const percent = (amount * (PAYMENT_SETTINGS.ADMIN_FEE.PERCENTAGE || 0)) / 100;
  return fixed + percent;
}

function calculateTotalAmount(amount) {
  return amount + calculateAdminFee(amount);
}

function loadData() {
  try {
    const file = fs.readFileSync(DATA_FILE, 'utf8');
    const data = file.length ? JSON.parse(file) : {};
    
    if (!data.users) data.users = [];
    if (!data.groups) data.groups = [];
    if (!data.blacklist) data.blacklist = [];
    if (!data.premium) data.premium = {};
    if (!data.owner) data.owner = OWNER_IDS;
    
    return data;
  } catch {
    return defaultData;
  }
}

function saveData(data) {
  if (!data) data = users;
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function isMainOwner(id) {
  return OWNER_IDS.map(String).includes(String(id));
}

function isAdditionalOwner(id) {
  const data = loadData();
  return Array.isArray(data.owner) && data.owner.map(String).includes(String(id));
}

function isCEO(id) {
  const data = loadData();
  return Array.isArray(data.ceo) && data.ceo.map(String).includes(String(id));
}

function isAnyOwner(id) {
  return isMainOwner(id) || isAdditionalOwner(id) || isCEO(id);
}

function isOwner(id) {
  return isAnyOwner(id);
}

function isPremium(id) {
  const data = loadData();
  const exp = data.premium[id];
  if (!exp) return false;
  const nowSec = Math.floor(Date.now() / 1000);
  return nowSec < exp;
}

async function cekAkses(level, msg) {
  const userId = msg.from.id.toString();
  const chatId = msg.chat.id;
  const nama = msg.from.first_name || "User";

  if (!(await requireNotBlacklisted(msg))) return false;
  if (!(await requireNotMaintenance(msg))) return false;
  if (!(await requireJoin(msg))) return false;

  const isMain = isMainOwner(userId);
  const isCeo = isCEO(userId);
  const isOwn = isAdditionalOwner(userId);
  const isPrem = isPremium(userId);

  async function gagal(pesan) {
    try {
      await bot.sendMessage(chatId, pesan, { parse_mode: "HTML" });
    } catch (e) {}
    return false;
  }

  switch ((level || "").toLowerCase()) {
    case "utama":
      if (!isMain) return gagal(`
<blockquote>🔐 Akses Khusus</blockquote>
• Hanya untuk Developer Utama
• User: ${nama}
• Status: ❌ Ditolak`);
      break;

    case "ceo":
      if (!isMain && !isCeo) return gagal(`
<blockquote>👑 Akses Khusus</blockquote>
• Hanya untuk CEO/Developer
• User: ${nama}
• Status: ❌ Ditolak`);
      break;

    case "owner":
      if (!isMain && !isCeo && !isOwn) return gagal(`
<blockquote>⚡ Akses Khusus</blockquote>
• Untuk Owner/CEO/Developer
• User: ${nama}
• Status: ❌ Ditolak`);
      break;

    case "premium":
      if (!isPrem && !isOwn && !isCeo && !isMain) return gagal(`
<blockquote>💎 Akses Khusus</blockquote>
• Hanya untuk Premium/Owner
• User: ${nama}
• Status: ❌ Ditolak`);
      break;

    default:
      return gagal(`
<blockquote>⚠️ Level Tidak Valid</blockquote>
• Level: ${level}
• Status: ❌ Tidak dikenal`);
  }

  return true;
}

async function cekGroupOnly(msg) {
  const data = loadData();
  if (!data.settings?.grouponly) return true;

  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
    await bot.sendMessage(
      msg.chat.id,
      `<blockquote>👥 Group Only</blockquote>
• Fitur hanya untuk grup
• Tipe chat: ${msg.chat.type}
• Status: ❌ Tidak bisa digunakan`,
      { parse_mode: "HTML" }
    );
    return false;
  }
  return true;
}

async function requireNotMaintenance(msg) {
  const userId = msg.from.id.toString();
  const chatId = msg.chat.id;

  const data = loadData();
  if (data.settings?.maintenance && !isMainOwner(userId)) {
    await bot.sendMessage(
      chatId,
      `<blockquote>🛠️ Maintenance Mode</blockquote>
• Bot sedang dalam perawatan
• User: ${msg.from.first_name}
• Status: ⏳ Sementara non-aktif`,
      { parse_mode: "HTML" }
    );
    return false;
  }
  return true;
}

async function requireNotBlacklisted(msg) {
  const userId = msg.from.id.toString();
  const data = loadData();
  if (data.blacklist?.includes(userId)) {
    await bot.sendMessage(
      userId,
      `<blockquote>🚫 Blacklisted</blockquote>
• User: ${msg.from.first_name}
• Status: ❌ Terblokir
• Hubungi admin untuk banding`,
      { parse_mode: "HTML" }
    );
    return false;
  }
  return true;
}


function getGlobalCooldownMs() {
  return getGlobalCooldownMinutes() * 60 * 1000;
}

function isBlacklisted(userId) {
  const data = loadData();
  return Array.isArray(data.blacklist) && data.blacklist.map(String).includes(String(userId));
}

const { writeFileSync, existsSync, mkdirSync } = require('fs');

function backupData() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupDir = './backup';
  const backupPath = `${backupDir}/data-${timestamp}.json`;

  if (!existsSync(backupDir)) mkdirSync(backupDir);
  if (!existsSync(DATA_FILE)) return null;
  const content = fs.readFileSync(DATA_FILE);
  writeFileSync(backupPath, content);

  return backupPath;
}
// === HANDLE BOT DITAMBAHKAN / DIKELUARKAN ===
bot.on("my_chat_member", async (msg) => {
  try {
    const data = loadData();
    const chat = msg.chat || msg.chat_member?.chat;
    const user = msg.from;
    const status = msg.new_chat_member?.status;
    const chatId = chat?.id;
    const userId = user?.id;

    if (!chat || !user || !status || !chatId || !userId) return;

    const isGroup = ["group", "supergroup"].includes(chat.type);
    const mainOwner = OWNER_IDS[0];
    const now = Math.floor(Date.now() / 1000);

    if (!data.groups) data.groups = [];
    if (!data.user_group_count) data.user_group_count = {};
    if (!data.premium) data.premium = {};

    // === BOT DITAMBAHKAN KE GRUP ===
    if (["member", "administrator"].includes(status) && isGroup) {
      if (data.premium[userId] && data.premium[userId] <= now) {
        delete data.premium[userId];
        console.log(`🔒 Premium expired & dihapus untuk ${userId} sebelum tambah grup`);
      }

      if (!data.groups.includes(chatId)) data.groups.push(chatId);

      data.user_group_count[userId] = (data.user_group_count[userId] || 0) + 1;

      let memberCount = 0;
      try {
        memberCount = await bot.getChatMemberCount(chatId);
      } catch {
        memberCount = 0;
      }
      
      const rewardSettings = getPremiumRewardSettings();
      const minGroupsRequired = rewardSettings.min_groups;
      const currentUserGroups = data.user_group_count[userId] || 0;

      if (currentUserGroups >= minGroupsRequired && memberCount >= 5) {
        const durasiDetik = rewardSettings.days * 86400;
        const current = data.premium[userId] || now;
        data.premium[userId] = current > now ? current + durasiDetik : now + durasiDetik;

        await bot.sendMessage(
          userId,
          `<blockquote>🎉 Terima Kasih!!</blockquote>

🌸 <b>Informasi Reward</b>
➥ <b>Grup:</b> ${chat.title}
➥ <b>Member:</b> ${memberCount} user
➥ <b>Total Grup Kamu:</b> ${currentUserGroups}/${minGroupsRequired}
➥ <b>Reward:</b> Premium ${rewardSettings.days} Hari
➥ <b>Status:</b> ✅ Aktif

📝 <b>Keterangan</b>
➥ Terima kasih telah menambahkan bot ke grup
➥ Akses premium telah diaktifkan selama ${rewardSettings.days} hari
➥ Nikmati semua fitur premium sekarang!`,
          { parse_mode: "HTML" }
        ).catch(() => {});

        const info = `
<blockquote>➕ </blockquote>

🌸 <b>Informasi Grup</b>
➥ <b>Pengguna:</b> <a href="tg://user?id=${userId}">${user.first_name}</a>
➥ <b>ID User:</b> <code>${userId}</code>
➥ <b>Username:</b> @${user.username || "-"}
➥ <b>Nama Grup:</b> ${chat.title}
➥ <b>ID Grup:</b> <code>${chatId}</code>
➥ <b>Member Grup:</b> ${memberCount}

🎁 <b>Reward Diberikan</b>
➥ <b>Total Grup User:</b> ${currentUserGroups}/${minGroupsRequired}
➥ <b>Akses:</b> Premium ${rewardSettings.days} Hari
➥ <b>Status:</b> ✅ Berhasil`;
        
        await bot.sendMessage(mainOwner, info, { parse_mode: "HTML" }).catch(() => {});

        const backupPath = backupData();
        if (backupPath) {
          await bot.sendDocument(mainOwner, backupPath, { 
            caption: `<blockquote>💾 </blockquote>
➥ <b>Trigger:</b> Bot ditambahkan ke grup baru
➥ <b>Waktu:</b> ${new Date().toLocaleString("id-ID")}`,
            parse_mode: "HTML" 
          }).catch(() => {});
        }
      } else {

        const rewardSettings = getPremiumRewardSettings();
        const currentUserGroups = data.user_group_count[userId] || 0;
        const minGroupsRequired = rewardSettings.min_groups;
        
        await bot.sendMessage(
          userId,
          `<blockquote>⚠️ </blockquote>

🌸 <b>Informasi Grup</b>
➥ <b>Grup:</b> ${chat.title}
➥ <b>Member:</b> ${memberCount} user
➥ <b>Total Grup Kamu:</b> ${currentUserGroups}/${minGroupsRequired}
➥ <b>Minimal Grup:</b> ${minGroupsRequired} grup
➥ <b>Status:</b> ❌ Belum memenuhi syarat

📝 <b>Keterangan</b>
➥ Tambahkan bot ke ${minGroupsRequired - currentUserGroups} grup lagi
➥ Setiap grup minimal 5 member
➥ Untuk mendapatkan premium ${rewardSettings.days} hari gratis`,
          { parse_mode: "HTML" }
        ).catch(() => {});
      }

      saveData(data);
    }

    // === BOT DIKELUARKAN DARI GRUP ===
    if (["left", "kicked", "banned", "restricted"].includes(status) && isGroup) {
      if (data.groups.includes(chatId)) {
        data.groups = data.groups.filter((id) => id !== chatId);
        data.user_group_count[userId] = Math.max(0, (data.user_group_count[userId] || 1) - 1);

        const rewardSettings = getPremiumRewardSettings();
        const currentUserGroups = data.user_group_count[userId] || 0;
        const minGroupsRequired = rewardSettings.min_groups;

        if (currentUserGroups < minGroupsRequired) {
         
          delete data.premium[userId];
          await bot.sendMessage(
            userId,
            `<blockquote>❌ </blockquote>

🌸 <b>Informasi Akses</b>
➥ <b>Status:</b> Bot dihapus dari grup
➥ <b>Total Grup Kamu:</b> ${currentUserGroups}/${minGroupsRequired}
➥ <b>Akses:</b> Premium dicabut
➥ <b>Grup:</b> ${chat.title}

📝 <b>Keterangan</b>
➥ Akses premium otomatis dicabut
➥ Tambahkan bot ke ${minGroupsRequired - currentUserGroups} grup lagi untuk mendapatkan premium kembali`,
            { parse_mode: "HTML" }
          ).catch(() => {});
        } else {
         
          await bot.sendMessage(
            userId,
            `<blockquote>⚠️ </blockquote>

🌸 <b>Informasi Grup</b>
➥ <b>Status:</b> Bot dihapus dari grup
➥ <b>Total Grup Kamu:</b> ${currentUserGroups}/${minGroupsRequired}
➥ <b>Akses:</b> Premium tetap aktif
➥ <b>Grup:</b> ${chat.title}

📝 <b>Keterangan</b>
➥ Premium tetap aktif karena masih memenuhi syarat
➥ Jaga total grup di atas ${minGroupsRequired} untuk tetap premium`,
            { parse_mode: "HTML" }
          ).catch(() => {});
        }

        const info = `
<blockquote>⚠️ </blockquote>

🌸 <b>Informasi Grup</b>
➥ <b>Pengguna:</b> <a href="tg://user?id=${userId}">${user.first_name}</a>
➥ <b>Username:</b> @${user.username || "-"}
➥ <b>ID User:</b> <code>${userId}</code>
➥ <b>Nama Grup:</b> ${chat.title}
➥ <b>ID Grup:</b> <code>${chatId}</code>
➥ <b>Total Grup User:</b> ${currentUserGroups}
➥ <b>Status Premium:</b> ${data.premium[userId] ? '✅ Aktif' : '❌ Dicabut'}`;

        await bot.sendMessage(mainOwner, info, { parse_mode: "HTML" }).catch(() => {});

        const backupPath = backupData();
        if (backupPath) {
          await bot.sendDocument(mainOwner, backupPath, { 
            caption: `<blockquote>💾 </blockquote>
➥ <b>Trigger:</b> Bot dikeluarkan dari grup
➥ <b>Waktu:</b> ${new Date().toLocaleString("id-ID")}`,
            parse_mode: "HTML" 
          }).catch(() => {});
        }

        saveData(data);
      }
    }
  } catch (err) {
    console.error("❌ Error my_chat_member:", err);
  }
});

// === CEK EXPIRED PREMIUM SETIAP MENIT ===
setInterval(() => {
  const data = loadData();
  const now = Math.floor(Date.now() / 1000);
  let expiredCount = 0;

  for (const uid in data.premium) {
    if (data.premium[uid] <= now) {
      delete data.premium[uid];
      expiredCount++;
      console.log(`🔒 Premium expired & dihapus untuk ${uid}`);

      bot.sendMessage(uid, `
💎 <b>Premium Expired</b>
Halo <b>Pengguna Unmey ☇</b> 🌸  
Masa aktif <b>Premium</b> kamu telah <b>berakhir</b> dan otomatis dicabut ⏳  

Untuk memperpanjang, tambahkan bot ke <b>2 grup baru (≥5 member)</b>  
atau hubungi admin untuk aktivasi manual 💎
`, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "💎 Perpanjang Premium", url: `https://t.me/${DEVELOPER.replace('@', '')}` }],
            [{ text: "📢 Channel Info", url: `https://t.me/${CHANNEL_USERNAME.replace('@', '')}` }]
          ]
        }
      }).catch(() => {});
    }
  }

  if (expiredCount > 0) {
    console.log(`✅ Berhasil hapus ${expiredCount} user premium yang expired`);
    saveData(data);
  }
}, 60 * 1000);

// === CEK JOIN CHANNEL ===
async function checkChannelMembership(userId) {
  try {
    const chatMember = await bot.getChatMember(CHANNEL_USERNAME, userId);
    return ["member", "administrator", "creator"].includes(chatMember.status);
  } catch {
    return false;
  }
}

async function requireJoin(msg) {
  const userId = msg.from.id;
  const isMember = await checkChannelMembership(userId);

  if (!isMember) {

    const originalCommand = msg.text || "/start";
    userPendingCommands[userId] = originalCommand;

    await bot.sendMessage(userId, `<blockquote>🚫 </blockquote>

🌸 <b>Informasi Akses</b>
➥ <b>User:</b> ${msg.from.first_name}
➥ <b>Status:</b> Belum bergabung channel
➥ <b>Akses:</b> Dibatasi

📝 <b>Keterangan</b>
➥ Kamu belum bergabung ke Channel Resmi kami
➥ Silakan join terlebih dahulu untuk menggunakan bot
➥ Setelah join, klik tombol "Coba Lagi"`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "📢 Gabung Channel Resmi", url: `https://t.me/${CHANNEL_USERNAME.replace('@','')}` }],
            [{ text: "🔄 Sudah Gabung, Coba Lagi", callback_data: "check_join_again" }]
          ]
        }
      });
    return false;
  }
  
  if (userPendingCommands[userId]) {
    delete userPendingCommands[userId];
  }
  
  return true;
}

const userPendingCommands = {};

function withRequireJoin(handler) {
  return async (msg, match) => {
    const ok = await requireJoin(msg);
    if (!ok) return;
    return handler(msg, match);
  };
}

// === CALLBACK JOIN CHECK ===
bot.on("callback_query", async (query) => {
  const userId = query.from.id.toString();
  const chatId = query.message.chat.id;

  if (query.data === "check_join_again") {
    await bot.answerCallbackQuery(query.id, {
      text: "🔄 Mengecek keanggotaan channel...",
      show_alert: false
    });

    const isMember = await checkChannelMembership(userId);

    if (isMember) {

      await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
      
      await bot.sendMessage(chatId, `<blockquote>✅ </blockquote>

🌸 <b>Informasi Akses</b>
➥ <b>Status:</b> Berhasil bergabung
➥ <b>Akses:</b> ✅ Diberikan

📝 <b>Keterangan</b>
➥ Sekarang kamu bisa menikmati semua fitur bot
➥ Command akan dijalankan otomatis...`,
        { parse_mode: "HTML" });

      const pendingCommand = userPendingCommands[userId];
      if (pendingCommand) {

        const simulatedMsg = {
          ...query.message,
          text: pendingCommand,
          from: query.from,
          chat: { id: chatId }
        };

        if (pendingCommand === "/start") {
          await bot.emit("text", simulatedMsg);
        } else {

          setTimeout(() => {
            bot.emit("text", simulatedMsg);
          }, 1000);
        }

        delete userPendingCommands[userId];
      } else {

        setTimeout(() => {
          bot.emit("text", {
            ...query.message,
            text: "/start",
            from: query.from,
            chat: { id: chatId }
          });
        }, 1000);
      }

    } else {
      await bot.editMessageText(`<blockquote>⚠️ </blockquote>

🌸 <b>Informasi Akses</b>
➥ <b>Status:</b> Masih belum bergabung
➥ <b>Akses:</b> ❌ Ditolak

📝 <b>Keterangan</b>
➥ Kamu belum bergabung di channel
➥ Silakan tekan tombol "Gabung Channel Resmi"
➥ Setelah join, klik tombol "Coba Lagi" lagi`,
        {
          chat_id: chatId,
          message_id: query.message.message_id,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "📢 Gabung Channel Resmi", url: `https://t.me/${CHANNEL_USERNAME.replace('@','')}` }],
              [{ text: "🔄 Sudah Gabung, Coba Lagi", callback_data: "check_join_again" }]
            ]
          }
        }
      );
    }
  }
});

// == START ==
bot.onText(/\/start/, withRequireJoin(async (msg) => {
  if (!(await requireNotBlacklisted(msg))) return;
  if (!(await requireNotMaintenance(msg))) return;
  
  const data = loadData();
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const waktuRunPanel = getUptime();
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  
  if ((msg.date * 1000) < BOT_START_TIME) return;

  // Initialize data structures if they don't exist
  if (!data.users) data.users = [];
  if (!data.groups) data.groups = [];
  if (!data.premium) data.premium = {};

  // Add user if not exists
  if (!data.users.includes(userId)) {
    data.users.push(userId);
    saveData(data);
  }

  const caption = `<blockquote>
<b>☇ —(👋) ᴡᴇʟᴄᴏᴍᴇ ʙᴀᴄᴋ ᴀɢᴇɴᴛ ${username} ᴘʟᴇᴀꜱᴇ ᴜꜱᴇ ᴛʜɪꜱ ʙᴏᴛ ᴀꜱ ʏᴏᴜ ᴡɪꜱʜ ,ᴛʜɪꜱ ʙᴏᴛ ᴡɪʟʟ ʜᴇʟᴘ ʏᴏᴜ ᴀɢᴇɴᴛ°</b></blockquote>
━━━━━━━━━━━━━━━━
[ INFORMATION ]
├─ Developer: ${DEVELOPER}
├─ Bot name: hadzzz
├─ Version: 2.4 - Vip version
├─ Prefix: /
└─ Agent name: ${username}

────────────────────
[ BOT STATISTICS ]
├─ Groups: ${data.groups.length}
├─ Users: ${data.users.length}
├─ AI: stable
└─ Uptime: ${waktuRunPanel}
━━━━━━━━━━━━━━━━
<blockquote>▣ ᴀ.ɪ ʀᴇᴀᴅʏ — ᴡᴀɪᴛɪɴɢ ɪɴᴘᴜᴛ  
▣ ᴇxᴇᴄᴜᴛᴇ ᴄᴏᴍᴍᴀɴᴅ ᴠɪᴀ ᴋᴇʏʙᴏᴀʀᴅ  
▣ ɢᴏᴏᴅ ʟᴜᴄᴋ, ᴀɢᴇɴᴛ <b>${username}</b> 🤖</blockquote>
`;

  await replaceMenu(chatId, caption, {
    keyboard: [
      [{ text: "ᴊᴀꜱʜᴇʀ ᴍᴇɴᴜ 📨" }],
      [{ text: "ꜱᴛᴀᴛᴜꜱ ᴀᴋᴜɴ 🧷" }],
      [{ text: "ᴛᴏᴏʟꜱ ᴍᴇɴᴜ 🛠️" }],
      [{ text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ 👑" }, { text: "ʜᴜʙᴜɴɢɪ ᴅᴇᴠ 🧑‍💻" }]
    ],
    resize_keyboard: true,
    one_time_keyboard: false
  });
}));

// === MAIN MENU ===
bot.on("message", async (msg) => {
  // Ignore non-text messages
  if (!msg.text) return;
  
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const text = msg.text;
  const data = loadData();
  const waktuRunPanel = getUptime();
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const ownerIdUtama = OWNER_IDS?.[0];

  // Initialize data if needed
  if (!data.users) data.users = [];
  if (!data.groups) data.groups = [];
  if (!data.premium) data.premium = {};

  // List of button texts that should trigger message deletion
  const buttonTexts = [
    "🔙 Kembali", 
    "ᴊᴀꜱʜᴇʀ ᴍᴇɴᴜ 📨", 
    "ᴏᴡɴᴇʀ ᴍᴇɴᴜ 👑", 
    "ᴛᴏᴏʟꜱ ᴍᴇɴᴜ 🛠️",
    "ꜱᴛᴀᴛᴜꜱ ᴀᴋᴜɴ 🧷", 
    "ʜᴜʙᴜɴɢɪ ᴅᴇᴠ 🧑‍💻", 
    "❌ Tutup Sesi"
  ];

  // Delete message if it's a button click
  if (buttonTexts.includes(text)) {
    try {
      await bot.deleteMessage(chatId, msg.message_id);
    } catch (e) {
      // Ignore deletion errors
    }
  }

  // === MAIN MENU ===
  if (text === "🔙 Kembali") {
    const caption = `<blockquote>
<b>☇ —(👋) ᴡᴇʟᴄᴏᴍᴇ ʙᴀᴄᴋ ᴀɢᴇɴᴛ ${username} ᴘʟᴇᴀꜱᴇ ᴜꜱᴇ ᴛʜɪꜱ ʙᴏᴛ ᴀꜱ ʏᴏᴜ ᴡɪꜱʜ ,ᴛʜɪꜱ ʙᴏᴛ ᴡɪʟʟ ʜᴇʟᴘ ʏᴏᴜ ᴀɢᴇɴᴛ°</b></blockquote>
━━━━━━━━━━━━━━━━
[ INFORMATION ]
├─ Developer: ${DEVELOPER}
├─ Bot name: hadzzz
├─ Version: 2.4 - Vip version
├─ Prefix: /
└─ Agent name: ${username}

────────────────────
[ BOT STATISTICS ]
├─ Groups: ${data.groups.length}
├─ Users: ${data.users.length}
├─ AI: stable
└─ Uptime: ${waktuRunPanel}
━━━━━━━━━━━━━━━━
<blockquote>▣ ᴀ.ɪ ʀᴇᴀᴅʏ — ᴡᴀɪᴛɪɴɢ ɪɴᴘᴜᴛ  
▣ ᴇxᴇᴄᴜᴛᴇ ᴄᴏᴍᴍᴀɴᴅ ᴠɪᴀ ᴋᴇʏʙᴏᴀʀᴅ  
▣ ɢᴏᴏᴅ ʟᴜᴄᴋ, ᴀɢᴇɴᴛ <b>${username}</b> 🤖</blockquote>
`;
    return replaceMenu(chatId, caption, {
      keyboard: [
        [{ text: "ᴊᴀꜱʜᴇʀ ᴍᴇɴᴜ 📨" }],
        [{ text: "ꜱᴛᴀᴛᴜꜱ ᴀᴋᴜɴ 🧷" }],
        [{ text: "ᴛᴏᴏʟꜱ ᴍᴇɴᴜ 🛠️" }],
        [{ text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ 👑" }, { text: "ʜᴜʙᴜɴɢɪ ᴅᴇᴠ 🧑‍💻" }]
      ],
      resize_keyboard: true,
      one_time_keyboard: false
    });
  }

  // === OWNER MENU ===
  if (text === "ᴏᴡɴᴇʀ ᴍᴇɴᴜ 👑") {
    if (!(await cekAkses("owner", msg))) {
      return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses ke menu ini!", {
        parse_mode: "HTML"
      });
    }
    
    const caption = `<blockquote>💎 ─── 《 ❝ ❞ 》 ─── 💎</blockquote>
🌸 <b>Informasi Owner</b>
➥ <b>Akses:</b> Owner & CEO
➥ <b>Status:</b> Menu khusus pemilik

🔧 <b>Command Management</b>
➥ <code>/settingbot</code> - Settings Bot
<blockquote>💎 Menu khusus untuk Owner bot</blockquote>
`;
    return replaceMenu(chatId, caption, {
      keyboard: [
        [{ text: "🔙 Kembali" }]
      ],
      resize_keyboard: true
    });
  }

  // === TOOLS MENU ===
  if (text === "ᴛᴏᴏʟꜱ ᴍᴇɴᴜ 🛠️") {
    const caption = `<blockquote>🧩 《 ❝Tools Menu❞ 》 🧩</blockquote>

🌸 <b>Informasi Tools</b>
➥ <b>Total Tools:</b> 9+ fitur
➥ <b>Status:</b> Semua tools aktif

🛠️ <b>Command Tools</b>
➥ <code>/update</code> - Update bot
➥ <code>/ping</code> - Cek status bot
➥ <code>/tourl</code> - Convert ke URL
➥ <code>/done</code> - Konfirmasi transaksi
➥ <code>/cekid</code> - Cek ID telegram
➥ <code>/backup</code> - Backup data

<blockquote>🧩 Berbagai tools utilitas untuk bot</blockquote>`;
    
    return replaceMenu(chatId, caption, {
      keyboard: [
        [{ text: "🔙 Kembali" }]
      ],
      resize_keyboard: true,
      one_time_keyboard: false
    });
  }

  // === JASHER MENU ===
  if (text === "ᴊᴀꜱʜᴇʀ ᴍᴇɴᴜ 📨") {
    const caption = `<blockquote>✨《 ❝  ❞ 》✨</blockquote>
🌸 <b>Informasi Jasher</b>
➥ <b>Fitur:</b> Auto messaging
➥ <b>Status:</b> Fitur broadcast

📨 <b>Command Jasher</b>
➥ <code>/auto on/off</code> - Aktifkan/nonaktifkan
➥ <code>/auto status</code> - Status auto
➥ <code>/sharemsg</code> - Share pesan
➥ <code>/broadcast</code> - Broadcast pesan

• <b>Capek harus masukin ke grup terus?, beli akses aja! ayo buruan chat ${DEVELOPER}</b>

<blockquote>✨ Fitur auto messaging dan broadcast</blockquote>
`;
    return replaceMenu(chatId, caption, {
      keyboard: [
        [{ text: "🔙 Kembali" }]
      ],
      resize_keyboard: true,
      one_time_keyboard: false
    });
  }

  // === STATUS AKUN ===
  if (text === "ꜱᴛᴀᴛᴜꜱ ᴀᴋᴜɴ 🧷") {
    const isMain = isMainOwner(userId);
    const isOwnerNow = isAnyOwner(userId);
    const isPremiumUser = data.premium?.[userId] && Math.floor(Date.now() / 1000) < data.premium[userId];
    const exp = isPremiumUser ? new Date(data.premium[userId] * 1000).toLocaleString("id-ID") : "Tidak ada";

    let status = "User Biasa";
    if (isMain) status = "👑 Pemilik Utama";
    else if (isOwnerNow) status = "💎 Owner";
    else if (isPremiumUser) status = "⭐ Premium";
    
    const expTime = isPremiumUser ? 
      `➥ <b>Kedaluwarsa:</b> <code>${exp}</code>` : 
      "➥ <b>Kedaluwarsa:</b> Tidak ada";

    const caption = `<blockquote>📊  《 ❝  ❞ 》  📊</blockquote>
🌸 <b>Informasi Akun</b>
➥ <b>Nama:</b> ${msg.from.first_name || "User"}
➥ <b>Username:</b> ${username}
➥ <b>User ID:</b> <code>${userId}</code>
➥ <b>Status:</b> ${status}
${expTime}

📈 <b>Statistik Sistem</b>
➥ <b>Uptime:</b> <code>${waktuRunPanel}</code>
➥ <b>Total User:</b> <code>${data.users.length}</code>
➥ <b>Total Group:</b> <code>${data.groups.length}</code>
<blockquote>📊 Informasi lengkap status akun Anda</blockquote>
`;
    return replaceMenu(chatId, caption, {
      keyboard: [
        [{ text: "🔙 Kembali" }]
      ],
      resize_keyboard: true,
      one_time_keyboard: false
    });
  }

  // === HUBUNGI ADMIN ===
  if (text === "ʜᴜʙᴜɴɢɪ ᴅᴇᴠ 🧑‍💻") {
    if (!ownerIdUtama) {
      return bot.sendMessage(chatId, "❌ Admin tidak tersedia saat ini.", {
        parse_mode: "HTML"
      });
    }
    
    // Initialize chatSessions if it doesn't exist
    if (!global.chatSessions) global.chatSessions = {};
    
    chatSessions[userId] = { 
      active: true, 
      ownerId: ownerIdUtama,
      chatId: chatId
    };
    
    const caption = `<blockquote>💬 《 ❝  ❞ 》 💬</blockquote>
🌸 <b>Sesi Obrolan Admin</b>
➥ <b>Status:</b> Sesi aktif
➥ <b>Admin:</b> <code>${ownerIdUtama}</code>

📝 <b>Instruksi</b>
➥ Silakan tulis pesan Anda untuk Admin
➥ Pesan akan langsung diteruskan ke Admin
➥ Gunakan tombol di bawah untuk menutup sesi

👋 Hai <b>${username}</b>, admin akan merespons secepatnya!`;
    
    return replaceMenu(chatId, caption, {
      keyboard: [
        [{ text: "❌ Tutup Sesi" }]
      ],
      resize_keyboard: true,
      one_time_keyboard: false
    });
  }

  // === BATALKAN SESI ADMIN ===
  if (text === "❌ Tutup Sesi" && chatSessions?.[userId]?.active) {
    delete chatSessions[userId];
    
    const caption = `<blockquote>❌ ─── 《 ❝ ❞ 》 ─── ❌</blockquote>

🌸 <b>Informasi Sesi</b>
➥ <b>Status:</b> Sesi ditutup
➥ <b>Pesan:</b> Terima kasih telah menghubungi admin

📝 Silakan hubungi admin lagi jika diperlukan`;
    
    return replaceMenu(chatId, caption, {
      keyboard: [
        [{ text: "🔙 Kembali" }]
      ],
      resize_keyboard: true,
      one_time_keyboard: false
    });
  }

  // === KIRIM PESAN KE ADMIN ===
  if (chatSessions?.[userId]?.active) {
    const ownerId = chatSessions[userId].ownerId;
    try {
      // Forward message to owner
      await bot.forwardMessage(ownerId, chatId, msg.message_id);
      
      // Send notification to user
      await bot.sendMessage(chatId, `
<blockquote>✅</blockquote>
➥ <b>Status:</b> Pesan berhasil dikirim ke Admin
➥ <b>Info:</b> Admin akan merespons secepatnya`, { 
        parse_mode: "HTML",
        reply_markup: {
          remove_keyboard: true
        }
      });
    } catch (error) {
      console.error("Error forwarding message:", error);
      delete chatSessions[userId];
      await bot.sendMessage(chatId, `
<blockquote>⚠️</blockquote>
➥ <b>Status:</b> Gagal mengirim pesan ke Admin
➥ <b>Solusi:</b> Coba lagi nanti atau hubungi langsung`, { 
        parse_mode: "HTML" 
      });
    }
    return;
  }

  // === OWNER BALAS USER ===
  if (isAnyOwner(userId) && msg.reply_to_message) {
    const replied = msg.reply_to_message;
    const fwdFrom = replied.forward_from;
    let targetUserId;
    
    if (fwdFrom) {
      targetUserId = fwdFrom.id.toString();
    } else if (replied.text?.includes("tg://user?id=")) {
      const match = replied.text.match(/tg:\/\/user\?id=(\d+)/);
      if (match) targetUserId = match[1];
    }

    if (targetUserId && chatSessions?.[targetUserId]?.active) {
      try {
        if (msg.text) {
          await bot.sendMessage(targetUserId, `👨‍💻 <b>Pesan dari Admin:</b>\n\n${msg.text}`, {
            parse_mode: "HTML"
          });
        } else if (msg.photo) {
          await bot.sendPhoto(targetUserId, msg.photo.pop().file_id, { 
            caption: msg.caption || ""
          });
        }
        
        await bot.sendMessage(userId, `
<blockquote>✅</blockquote>
➥ <b>Status:</b> Pesan berhasil dikirim ke user
➥ <b>User ID:</b> <code>${targetUserId}</code>`, { 
          parse_mode: "HTML" 
        });
      } catch (error) {
        console.error("Error sending message to user:", error);
        await bot.sendMessage(userId, `
<blockquote>⚠️</blockquote>
➥ <b>Status:</b> Gagal mengirim ke user
➥ <b>User ID:</b> <code>${targetUserId}</code>
➥ <b>Error:</b> ${error.message}`, { 
          parse_mode: "HTML" 
        });
      }
    }
  }
});

async function replaceMenu(chatId, caption, buttons) {
  try {
    // Delete previous menu if exists
    if (activeMenus?.[chatId]) {
      try {
        await bot.deleteMessage(chatId, activeMenus[chatId]);
      } catch (e) {
        // Ignore deletion errors
      }
      delete activeMenus[chatId];
    }

    // Try sending with photo first
    let sent;
    try {
      const photo = getRandomImage(); // Make sure this function exists
      sent = await bot.sendPhoto(chatId, photo, {
        caption,
        parse_mode: "HTML",
        reply_markup: {
          keyboard: buttons.keyboard,
          resize_keyboard: buttons.resize_keyboard,
          one_time_keyboard: buttons.one_time_keyboard || false
        }
      });
    } catch (photoError) {
      // Fallback to text message if photo fails
      sent = await bot.sendMessage(chatId, caption, {
        parse_mode: "HTML",
        reply_markup: {
          keyboard: buttons.keyboard,
          resize_keyboard: buttons.resize_keyboard,
          one_time_keyboard: buttons.one_time_keyboard || false
        }
      });
    }

    // Store the new menu message ID
    if (!global.activeMenus) global.activeMenus = {};
    activeMenus[chatId] = sent.message_id;
    
  } catch (err) {
    console.error("replaceMenu error:", err);
    throw err;
  }
}

// === /sharemsg ===
bot.onText(/^\/sharemsg$/, async (msg) => {
  if (!(await cekAkses("premium", msg))) return;
  if (!(await requireNotBlacklisted(msg))) return;
  if (!(await requireNotMaintenance(msg))) return;

  const senderId = msg.from.id.toString();
  const chatId = msg.chat.id;
  const data = loadData();

  const isPremium = data.premium?.[senderId] && Math.floor(Date.now() / 1000) < data.premium[senderId];
  const isOwner = isAnyOwner(senderId);

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, `
<blockquote>❌ </blockquote>

🌸 <b>Cara Penggunaan</b>
➥ <b>1.</b> Reply pesan yang ingin di-share
➥ <b>2.</b> Ketik <code>/sharemsg</code>

📝 <b>Keterangan</b>
➥ Pesan akan dikirim ke semua grup terdaftar
➥ Fitur khusus user premium

👋 Hai <b>${msg.from.first_name}</b> 🌸`, 
    { parse_mode: "HTML" });
  }

  const keyboard = { inline_keyboard: [] };

  keyboard.inline_keyboard.push([
    { 
      text: "📤 Copy Message", 
      callback_data: `sharemsg_copy_${chatId}_${msg.reply_to_message.message_id}_${senderId}` 
    },
  ]);

  if (isOwner) {
    keyboard.inline_keyboard.push([
      { 
        text: "📎 Forward Message", 
        callback_data: `sharemsg_forward_${chatId}_${msg.reply_to_message.message_id}_${senderId}` 
      },
    ]);
  }

  await bot.sendMessage(
    chatId,
    `<blockquote>📤 sabar</blockquote>

🌸 <b>Metode Pengiriman</b>
${isOwner ? 
`➥ <b>📤 Copy Message</b>
  └ Tanpa label "Forwarded"
  
➥ <b>📎 Forward Message</b>
  └ Dengan label asli` :
`➥ <b>📤 Copy Message</b>
  └ Tanpa label "Forwarded"`}

📝 <b>Keterangan</b>
➥ Pilih metode sesuai kebutuhan Anda
➥ Pesan akan dikirim ke semua grup`,
    { parse_mode: "HTML", reply_markup: keyboard }
  );
});

bot.on("callback_query", async (query) => {
  try {
    const data = query.data;
    if (!data.startsWith("sharemsg_")) return;

    const [_, mode, chatId, replyMsgId, ownerId] = data.split("_");
    const fromId = query.from.id.toString();

    if (fromId !== ownerId) {
      return bot.answerCallbackQuery(query.id, { 
        text: "❌ Tombol ini bukan untuk kamu!", 
        show_alert: true 
      });
    }

    await bot.editMessageReplyMarkup(
      { inline_keyboard: [] },
      { chat_id: query.message.chat.id, message_id: query.message.message_id }
    ).catch(() => {});
    
    await bot.answerCallbackQuery(query.id, { 
      text: "🔄 Memproses pengiriman...", 
      show_alert: false 
    });

    const store = loadData();
    const groups = store.groups || [];
    const mainOwner = OWNER_IDS?.[0];

    if (groups.length === 0) {
      return bot.sendMessage(chatId, `
<blockquote>❌ </blockquote>
➥ <b>Status:</b> Belum ada grup terdaftar
➥ <b>Solusi:</b> Tambahkan grup terlebih dahulu`, 
      { parse_mode: "HTML" });
    }

    const total = groups.length;
    let sukses = 0, gagal = 0;
    let processed = 0;

    const statusMsg = await bot.sendMessage(
      chatId,
      `<blockquote>📡 </blockquote>

🌸 <b>Informasi Pengiriman</b>
➥ <b>Total Grup:</b> ${total}
➥ <b>Status:</b> <code>Memulai...</code>
➥ <b>Progress:</b> 0/${total} (0%)

📊 <b>Progress Bar</b>
[░░░░░░░░░░] 0%`,
      { parse_mode: "HTML" }
    );

    for (const groupId of groups) {
      try {
        if (mode === "copy") {
          await bot.copyMessage(groupId, chatId, parseInt(replyMsgId));
        } else {
          await bot.forwardMessage(groupId, chatId, parseInt(replyMsgId));
        }
        sukses++;
      } catch {
        gagal++;
      }
      processed++;

      if (processed % 5 === 0 || processed === total) {
        const progress = Math.round((processed / total) * 100);
        const progressBar = createProgressBar(progress);
        try {
          await bot.editMessageText(
            `<blockquote>📡 </blockquote>

🌸 <b>Informasi Pengiriman</b>
➥ <b>Total Grup:</b> ${total}
➥ <b>Status:</b> <code>Berjalan...</code>
➥ <b>Progress:</b> ${processed}/${total} (${progress}%)
➥ <b>✅ Berhasil:</b> ${sukses}
➥ <b>❌ Gagal:</b> ${gagal}

📊 <b>Progress Bar</b>
${progressBar} ${progress}%`,
            {
              chat_id: chatId,
              message_id: statusMsg.message_id,
              parse_mode: "HTML"
            }
          );
        } catch (e) {}
      }
      
      await new Promise((r) => setTimeout(r, 300));
    }

    const hasil = `
<blockquote>✅ </blockquote>

🌸 <b>Hasil Pengiriman</b>
➥ <b>Total Grup:</b> ${total}
➥ <b>✅ Berhasil:</b> ${sukses}
➥ <b>❌ Gagal:</b> ${gagal}
➥ <b>Mode:</b> ${mode === "copy" ? "Copy Message" : "Forward Message"}
➥ <b>Success Rate:</b> ${Math.round((sukses / total) * 100)}%

📝 <b>Keterangan</b>
➥ Pesan berhasil disebarkan ke ${sukses} grup`;

    await bot.editMessageText(hasil, {
      chat_id: chatId,
      message_id: statusMsg.message_id,
      parse_mode: "HTML",
    });

    if (mainOwner && mainOwner !== fromId) {
      const user = query.from;
      const laporan = `
<blockquote>📢 </blockquote>

🌸 <b>Informasi User</b>
➥ <b>User:</b> <a href="tg://user?id=${fromId}">${user.first_name}</a>
➥ <b>ID:</b> <code>${fromId}</code>

📊 <b>Hasil Pengiriman</b>
➥ <b>Total Grup:</b> ${total}
➥ <b>✅ Berhasil:</b> ${sukses}
➥ <b>❌ Gagal:</b> ${gagal}
➥ <b>Mode:</b> ${mode === "copy" ? "Copy" : "Forward"}
➥ <b>Waktu:</b> ${new Date().toLocaleString("id-ID")}`;
      
      await bot.sendMessage(mainOwner, laporan, { 
        parse_mode: "HTML" 
      }).catch(() => {});
    }
  } catch (err) {
    console.error("❌ Error sharemsg:", err);
    bot.sendMessage(query.message.chat.id, `
<blockquote>❌ 𝗘𝗿𝗿𝗼𝗿</blockquote>
➥ <b>Status:</b> Terjadi kesalahan saat memproses
➥ <b>Solusi:</b> Silakan coba lagi nanti`, 
    { parse_mode: "HTML" });
  }
});

// === /broadcast ===
bot.onText(/^\/broadcast$/, async (msg) => {
  if (!(await cekAkses("owner", msg))) return;
  if (!(await requireNotBlacklisted(msg))) return;
  if (!(await requireNotMaintenance(msg))) return;

  const senderId = msg.from.id.toString();
  const chatId = msg.chat.id;
  const data = loadData();

  try {
    const isMain = isMainOwner(senderId);
    
    if (!isMain) {
      if (!data.cooldowns) data.cooldowns = {};
      if (!data.cooldowns.broadcast) data.cooldowns.broadcast = {};

      const now = Math.floor(Date.now() / 1000);
      const lastUse = data.cooldowns.broadcast[senderId] || 0;
      const cooldown = getGlobalCooldownMinutes() * 60;

      if (now - lastUse < cooldown) {
        const sisa = cooldown - (now - lastUse);
        const menit = Math.floor(sisa / 60);
        const detik = sisa % 60;
        return bot.sendMessage(
          chatId,
          `<blockquote>⏳ </blockquote>

🌸 <b>Informasi Cooldown</b>
➥ <b>Tunggu:</b> ${menit}m ${detik}s
➥ <b>Status:</b> Sebelum bisa broadcast lagi

📝 <b>Keterangan</b>
➥ Fitur broadcast memiliki jeda waktu
➥ Silakan tunggu hingga cooldown selesai`,
          { parse_mode: "HTML" }
        );
      }

      data.cooldowns.broadcast[senderId] = now;
      saveData(data);
    }

    if (!msg.reply_to_message) {
      return bot.sendMessage(chatId, `
<blockquote>❌</blockquote>

🌸 <b>Cara Penggunaan</b>
➥ <b>1.</b> Reply pesan yang ingin di-broadcast
➥ <b>2.</b> Ketik <code>/broadcast</code>

📝 <b>Keterangan</b>
➥ Pesan akan dikirim ke semua user terdaftar`,
      { parse_mode: "HTML" });
    }

    const users = [...new Set(data.users || [])];
    if (users.length === 0) {
      return bot.sendMessage(chatId, `
<blockquote>❌</blockquote>
➥ <b>Status:</b> Belum ada user terdaftar
➥ <b>Solusi:</b> Tunggu hingga ada user bergabung`, 
      { parse_mode: "HTML" });
    }

    const total = users.length;
    let sukses = 0, gagal = 0;
    let processed = 0;
    const reply = msg.reply_to_message;

    const statusMsg = await bot.sendMessage(
      chatId,
      `<blockquote>📡 𝗠𝗲𝗺𝘂𝗹𝗮𝗶 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁</blockquote>

🌸 <b>Informasi Broadcast</b>
➥ <b>Total User:</b> ${total}
➥ <b>Status:</b> <code>Memulai...</code>
➥ <b>Progress:</b> 0/${total} (0%)

📊 <b>Progress Bar</b>
[░░░░░░░░░░] 0%`,
      { parse_mode: "HTML" }
    );

    for (const userId of users) {
      try {
        await bot.copyMessage(userId, chatId, reply.message_id);
        sukses++;
      } catch {
        gagal++;
      }
      processed++;
      
      if (processed % 10 === 0 || processed === total) {
        const progress = Math.round((processed / total) * 100);
        const progressBar = createProgressBar(progress);
        try {
          await bot.editMessageText(
            `<blockquote>📡</blockquote>

🌸 <b>Informasi Broadcast</b>
➥ <b>Total User:</b> ${total}
➥ <b>Status:</b> <code>Berjalan...</code>
➥ <b>Progress:</b> ${processed}/${total} (${progress}%)
➥ <b>✅ Berhasil:</b> ${sukses}
➥ <b>❌ Gagal:</b> ${gagal}

📊 <b>Progress Bar</b>
${progressBar} ${progress}%`,
            {
              chat_id: chatId,
              message_id: statusMsg.message_id,
              parse_mode: "HTML"
            }
          );
        } catch (e) {}
      }
      
      await new Promise((r) => setTimeout(r, 300));
    }

    await bot.editMessageText(
      `<blockquote>✅ </blockquote>

🌸 <b>Hasil Pengiriman</b>
➥ <b>Total User:</b> ${total}
➥ <b>✅ Berhasil:</b> ${sukses}
➥ <b>❌ Gagal:</b> ${gagal}
➥ <b>Success Rate:</b> ${Math.round((sukses / total) * 100)}%

📝 <b>Keterangan</b>
➥ Pesan berhasil dikirim ke ${sukses} user`,
      {
        chat_id: chatId,
        message_id: statusMsg.message_id,
        parse_mode: "HTML",
      }
    );
  } catch (err) {
    console.error("❌ Error broadcast:", err);
    bot.sendMessage(chatId, `
<blockquote>❌ </blockquote>
➥ <b>Status:</b> Terjadi kesalahan saat memproses
➥ <b>Solusi:</b> Silakan coba lagi nanti`, 
    { parse_mode: "HTML" });
  }
});

// === /autoshare ===
bot.onText(/^\/auto\s*(on|off|status)?$/i, async (msg, match) => {
  if (!(await cekAkses("owner", msg))) return;

  const userId = msg.from.id.toString();
  const chatId = msg.chat.id;
  const arg = (match[1] || "").toLowerCase();

  if (!autoForwards[userId]) {
    autoForwards[userId] = {
      active: false,
      original: null,
      lastSent: 0,
      round: 1,
      username: msg.from.username || "unknown",
      scheduledStart: 0,
      statusMessageId: null
    };
  }

  const conf = autoForwards[userId];

  if (arg === "off") {
    conf.active = false;
    conf.scheduledStart = 0;

    if (conf.statusMessageId) {
      try {
        await bot.deleteMessage(chatId, conf.statusMessageId);
      } catch (e) {}
      conf.statusMessageId = null;
    }
    return bot.sendMessage(chatId, `
<blockquote>❌ </blockquote>

🌸 <b>Informasi Sistem</b>
➥ <b>Status:</b> AutoForward dihentikan
➥ <b>Putaran:</b> ${conf.round}
➥ <b>Mode:</b> Nonaktif

📝 <b>Keterangan</b>
➥ Sistem auto-forward telah dihentikan`,
    { parse_mode: "HTML" });
  }

  if (arg === "status") {
    const status = conf.active ? 
      (conf.scheduledStart > Date.now() ? "⏳ MENUNGGU JEDA" : "🟢 AKTIF") : 
      "🔴 NONAKTIF";
    const source = conf.original ? "✅ Tersedia" : "❌ Belum diset";
    const groups = loadData().groups || [];
    const waitingTime = conf.scheduledStart > Date.now() ? 
      `\n➥ <b>⏰ Mulai dalam:</b> ${Math.ceil((conf.scheduledStart - Date.now()) / 1000)} detik` : "";
    
    return bot.sendMessage(chatId, `
<blockquote>📊 </blockquote>

🌸 <b>Informasi Status</b>
➥ <b>Status:</b> ${status}${waitingTime}
➥ <b>Pesan:</b> ${source}
➥ <b>Grup Target:</b> ${groups.length} grup
➥ <b>Putaran:</b> ${conf.round} kali
➥ <b>Jeda:</b> ${getGlobalCooldownMinutes()} menit`,
    { parse_mode: "HTML" });
  }

  if (!conf.original) {
    return bot.sendMessage(chatId, `
<blockquote>⚠️ </blockquote>

🌸 <b>Cara Penggunaan</b>
➥ <b>1.</b> Reply pesan yang ingin di-auto forward
➥ <b>2.</b> Ketik <code>/setpesan</code>

📝 <b>Keterangan</b>
➥ Set pesan terlebih dahulu sebelum mengaktifkan`,
    { parse_mode: "HTML" });
  }

  conf.scheduledStart = Date.now() + 5000; 
  conf.active = true;
  const groups = loadData().groups || [];
  
  const statusMsg = await bot.sendMessage(chatId, `
<blockquote>⏳ </blockquote>

🌸 <b>Informasi Jadwal</b>
➥ <b>Status:</b> ⏳ MENUNGGU
➥ <b>Grup Target:</b> ${groups.length} grup
➥ <b>Mulai dalam:</b> 5 detik
➥ <b>Putaran berikutnya:</b> ${conf.round}

📝 <b>Keterangan</b>
➥ AutoForward akan mulai otomatis dalam 5 detik
➥ Sistem akan berjalan terus hingga dimatikan`,
  { parse_mode: "HTML" });

  conf.statusMessageId = statusMsg.message_id;
});

setInterval(async () => {
  try {
    const now = Date.now();
    const data = loadData();
    const groups = data.groups || [];
    if (!groups.length) return;

    const cooldownMs = getGlobalCooldownMs();
    const delayPerGroup = 300;

    for (const userId in autoForwards) {
      const conf = autoForwards[userId];
      
      if (conf.active && conf.statusMessageId) {
        try {
          const timeLeft = conf.scheduledStart > now ? Math.ceil((conf.scheduledStart - now) / 1000) : 0;
          const statusText = conf.scheduledStart > now ? 
            `⏳ MENUNGGU (${timeLeft}s)` : "🟢 SEDANG BERJALAN";

          await bot.editMessageText(`
<blockquote>🔄 </blockquote>

🌸 <b>Informasi Status</b>
➥ <b>Status:</b> ${statusText}
➥ <b>Grup Target:</b> ${groups.length} grup
➥ <b>Putaran berikutnya:</b> ${conf.round}
➥ <b>Jeda:</b> ${getGlobalCooldownMinutes()} menit
${conf.scheduledStart > now ? `➥ <b>⏰ Mulai dalam:</b> ${timeLeft} detik` : '➥ <b>🎯 Status:</b> Sedang memproses...'}`,
          {
            chat_id: userId,
            message_id: conf.statusMessageId,
            parse_mode: "HTML"
          });
        } catch (e) {
          if (e.response && e.response.statusCode === 400) {
            conf.statusMessageId = null;
          }
        }
      }
      
      if (conf.active && conf.scheduledStart > 0 && now >= conf.scheduledStart) {
        console.log(`🚀 Starting auto-forward for user ${userId}, round ${conf.round}`);
        
        conf.scheduledStart = 0;
        conf.lastSent = now;

        if (conf.statusMessageId) {
          try {
            await bot.editMessageText(`
<blockquote>🎯</blockquote>

🌸 <b>Informasi Proses</b>
➥ <b>Status:</b> 🟢 SEDANG BERJALAN
➥ <b>Grup Target:</b> ${groups.length} grup
➥ <b>Putaran:</b> ${conf.round}
➥ <b>Progress:</b> Memulai pengiriman...

📝 <b>Keterangan</b>
➥ Mengirim ke ${groups.length} grup...`,
            {
              chat_id: userId,
              message_id: conf.statusMessageId,
              parse_mode: "HTML"
            });
          } catch (e) {}
        }

        let sukses = 0, gagal = 0;
        let processed = 0;

        for (const groupId of groups) {
          try {
            await bot.copyMessage(groupId, conf.original.chatId, conf.original.messageId);
            sukses++;
          } catch (error) {
            console.log(`❌ Gagal kirim ke ${groupId}:`, error.message);
            gagal++;
          }
          processed++;
          
          if (conf.statusMessageId && (processed % 10 === 0 || processed === groups.length)) {
            const progress = Math.round((processed/groups.length)*100);
            const progressBar = createProgressBar(progress);
            try {
              await bot.editMessageText(`
<blockquote>🎯</blockquote>

🌸 <b>Informasi Proses</b>
➥ <b>Status:</b> 🟢 SEDANG BERJALAN
➥ <b>Grup Target:</b> ${groups.length} grup
➥ <b>Putaran:</b> ${conf.round}
➥ <b>Progress:</b> ${processed}/${groups.length} (${progress}%)
➥ <b>✅ Berhasil:</b> ${sukses}
➥ <b>❌ Gagal:</b> ${gagal}

📊 <b>Progress Bar</b>
${progressBar} ${progress}%`,
              {
                chat_id: userId,
                message_id: conf.statusMessageId,
                parse_mode: "HTML"
              });
            } catch (e) {}
          }
          
          await new Promise((r) => setTimeout(r, delayPerGroup));
        }

        if (conf.statusMessageId) {
          try {
            await bot.editMessageText(`
<blockquote>✅ </blockquote>

🌸 <b>Hasil Putaran ${conf.round}</b>
➥ <b>Status:</b> ⏳ MENUNGGU JEDA BERIKUTNYA
➥ <b>✅ Berhasil:</b> ${sukses}
➥ <b>❌ Gagal:</b> ${gagal}
➥ <b>Total:</b> ${groups.length} grup
➥ <b>Jeda berikutnya:</b> ${getGlobalCooldownMinutes()} menit
➥ <b>Putaran selanjutnya:</b> ${conf.round + 1}

📝 <b>Keterangan</b>
➥ Putaran berikutnya dalam ${getGlobalCooldownMinutes()} menit...`,
            {
              chat_id: userId,
              message_id: conf.statusMessageId,
              parse_mode: "HTML"
            });
          } catch (e) {}
        }

        conf.round++;
        conf.scheduledStart = now + cooldownMs;
      }
    }
  } catch (err) {
    console.error("❌ Error in auto-forward loop:", err);
  }
}, 2000);

function createProgressBar(percentage) {
  const bars = 10;
  const filledBars = Math.round((percentage / 100) * bars);
  const emptyBars = bars - filledBars;
  return `[${'█'.repeat(filledBars)}${'░'.repeat(emptyBars)}]`;
}

bot.onText(/^\/setpesan$/, async (msg) => {
  if (!(await cekAkses("owner", msg))) return;

  const userId = msg.from.id.toString();
  const chatId = msg.chat.id;

  if (!msg.reply_to_message)
    return bot.sendMessage(chatId, "⚠️ Harap *reply* ke pesan yang ingin disimpan untuk auto-forward.", { parse_mode: "Markdown" });

  autoForwards[userId] = {
    active: false,
    original: {
      chatId: msg.reply_to_message.chat.id,
      messageId: msg.reply_to_message.message_id
    },
    lastSent: 0,
    round: 1,
    username: msg.from.username || "unknown"
  };

  bot.sendMessage(chatId, "✅ Pesan berhasil disimpan.\nGunakan `/auto on` untuk mulai mengirim otomatis.", { parse_mode: "Markdown" });
});

// === /setjeda ===
bot.onText(/^\/setjeda(?:\s+(\d+))?$/, async (msg, match) => {
  const senderId = msg.from.id.toString();
  const chatId = msg.chat.id;
  
  const config = require('./config.js');
  const ownerIds = config.OWNER_IDS || [];
  const mainOwnerIds = ownerIds.map(id => id.toString());
  
  if (!mainOwnerIds.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Akses Ditolak:\nHanya Unmey Yang Bisa Menggunakan Perintah Ini!").catch(() => {});
  }

  const data = loadData();
  if (!data.settings) data.settings = {};
  if (!data.settings.cooldown) data.settings.cooldown = {};

  const menit = parseInt(match[1]);
  
  if (!match[1]) {
    return bot.sendMessage(chatId, "⚠️ Format salah. Contoh: `/setjeda 15`", { parse_mode: "Markdown" });
  }

  if (isNaN(menit) || menit <= 0) {
    const current = getGlobalCooldownMinutes();
    return bot.sendMessage(chatId, `⚙️ Cooldown saat ini: *${current} menit*`, { parse_mode: "Markdown" });
  }

  data.settings.cooldown.default = menit;
  saveData(data);

  return bot.sendMessage(chatId, `✅ Jeda berhasil diatur ke *${menit} menit*.`, { parse_mode: "Markdown" });
});

// === /settingbot - BOT SETTINGS MANAGEMENT ===
bot.onText(/^\/settingbot$/i, async (msg) => {
  if (!(await cekAkses("owner", msg))) return;
  
  const chatId = msg.chat.id;
  const data = loadData();
  const settings = data.settings || {};
  
  const caption = `<blockquote>⚙️ </blockquote>

📊 <b>STATISTIK SISTEM</b>
├ Users: <code>${data.users?.length || 0}</code>
├ Groups: <code>${data.groups?.length || 0}</code>  
├ Premium: <code>${Object.keys(data.premium || {}).length}</code>
└ Blacklist: <code>${data.blacklist?.length || 0}</code>

🔧 <b>PENGATURAN AKTIF</b>
├ Group Only: ${settings.grouponly ? "✅" : "❌"}
├ Maintenance: ${settings.maintenance ? "✅" : "❌"}  
├ Cooldown: <code>${settings.cooldown?.default || 15}m</code>

💡 <i>Pilih menu di bawah untuk mengatur bot</i>`;

  await bot.sendMessage(chatId, caption, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: "👤 User Mgmt", callback_data: "setting_viewuser" },
          { text: "💎 Premium", callback_data: "setting_premium" }
        ],
        [
          { text: "👑 Owner", callback_data: "setting_owner" },
          { text: "🚫 Blacklist", callback_data: "setting_blacklist" }
        ],
        [
          { text: "🛠️ Maintenance", callback_data: "setting_maintenance" },
          { text: "👥 Group Only", callback_data: "setting_grouponly" }
        ],
        [
          { text: "📊 Stats", callback_data: "setting_stats" }
        ],
        [
          { text: "🎁 Reward Settings", callback_data: "setting_reward" }
        ]
      ]
    }
  });
});

// === CALLBACK HANDLER SETTINGBOT ===
bot.on("callback_query", async (query) => {
  const data = query.data;
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  
  try {
    await bot.answerCallbackQuery(query.id);

    // BACK TO SETTINGS
    if (data === "back_to_settings") {
      const dataObj = loadData();
      const settings = dataObj.settings || {};
      
      const caption = `<blockquote>⚙️ </blockquote>

📊 <b>STATISTIK SISTEM</b>
├ Users: <code>${dataObj.users?.length || 0}</code>
├ Groups: <code>${dataObj.groups?.length || 0}</code>  
├ Premium: <code>${Object.keys(dataObj.premium || {}).length}</code>
└ Blacklist: <code>${dataObj.blacklist?.length || 0}</code>

🔧 <b>PENGATURAN AKTIF</b>
├ Group Only: ${settings.grouponly ? "✅" : "❌"}
├ Maintenance: ${settings.maintenance ? "✅" : "❌"}  
├ Cooldown: <code>${settings.cooldown?.default || 15}m</code>

💡 <i>Pilih menu di bawah untuk mengatur bot</i>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "👤 User Mgmt", callback_data: "setting_viewuser" },
              { text: "💎 Premium", callback_data: "setting_premium" }
            ],
            [
              { text: "👑 Owner", callback_data: "setting_owner" },
              { text: "🚫 Blacklist", callback_data: "setting_blacklist" }
            ],
            [
              { text: "🛠️ Maintenance", callback_data: "setting_maintenance" },
              { text: "👥 Group Only", callback_data: "setting_grouponly" }
            ],
            [
              { text: "📊 Stats", callback_data: "setting_stats" }
            ],
            [
              { text: "🎁 Reward Settings", callback_data: "setting_reward" }
            ]
          ]
        }
      });
      return;
    }

    // VIEW USER MANAGEMENT
    if (data === "setting_viewuser") {
      const dataObj = loadData();
      const totalUsers = dataObj.users?.length || 0;
      
      const caption = `<blockquote>👤 </blockquote>

📊 <b>USER STATISTICS</b>
├ Total Users: <code>${totalUsers}</code>
├ Active Users: <code>${Math.floor(totalUsers * 0.8)}</code>
├ New Today: <code>${Math.floor(totalUsers * 0.05)}</code>
└ Growth Rate: <code>${Math.floor(totalUsers * 0.1)}/month</code>

🔧 <b>USER MANAGEMENT TOOLS</b>
Pilih tool management di bawah:`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔍 Search User", callback_data: "user_search" },
              { text: "📋 List Users", callback_data: "user_list" }
            ],
            [
              { text: "🚫 Add Blacklist", callback_data: "user_blacklist_add" },
              { text: "✅ Remove Blacklist", callback_data: "user_blacklist_remove" }
            ],
            [
              { text: "💎 Add Premium", callback_data: "user_premium_add" },
              { text: "❌ Remove Premium", callback_data: "user_premium_remove" }
            ],
            [
              { text: "🔙 Back", callback_data: "back_to_settings" }
            ]
          ]
        }
      });
      return;
    }

    // USER SEARCH
    if (data === "user_search") {
      const caption = `<blockquote>🔍 </blockquote>

📝 <b>CARI USER</b>
Kirim User ID atau Username:

<code>Contoh:</code>
• <code>123456789</code> (User ID)
• <code>@username</code> (Username)

⚠️ Bot akan mencari user di database`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_viewuser" }
            ]
          ]
        }
      });
      
      userSearchSessions[chatId] = { waitingForInput: true };
      return;
    }

    // LIST USERS
    if (data === "user_list") {
      const dataObj = loadData();
      const users = dataObj.users || [];
      
      if (users.length === 0) {
        const caption = `<blockquote>📋 </blockquote>
❌ <b>Tidak ada user terdaftar</b>`;

        await bot.editMessageText(caption, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: "🔄 Refresh", callback_data: "user_list" }
              ],
              [
                { text: "🔙 Back", callback_data: "setting_viewuser" }
              ]
            ]
          }
        });
        return;
      }

      let userListText = "";
      users.slice(-10).reverse().forEach((userId, index) => {
        const isPremium = dataObj.premium?.[userId] && dataObj.premium[userId] > Math.floor(Date.now() / 1000);
        const status = isPremium ? "💎" : "👤";
        userListText += `├ ${status} <code>${userId}</code>\n`;
      });

      const caption = `<blockquote>📋  (10 Terbaru)</blockquote>

${userListText}
📊 <b>TOTAL</b>
└ Users: <code>${users.length}</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "user_list" }
            ],
            [
              { text: "🔙 Back", callback_data: "setting_viewuser" }
            ]
          ]
        }
      });
      return;
    }

    // ADD USER TO BLACKLIST
    if (data === "user_blacklist_add") {
      const caption = `<blockquote>🚫 </blockquote>

📝 <b>TAMBAH BLACKLIST</b>
Kirim User ID yang ingin di-blacklist:

<code>Contoh: 123456789</code>

⚠️ User akan diblokir dari menggunakan bot`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_viewuser" }
            ]
          ]
        }
      });
      
      userBlacklistSessions[chatId] = { action: "add" };
      return;
    }

    // REMOVE USER FROM BLACKLIST
    if (data === "user_blacklist_remove") {
      const dataObj = loadData();
      const blacklistCount = dataObj.blacklist?.length || 0;
      
      const caption = `<blockquote>✅</blockquote>

📝 <b>HAPUS BLACKLIST</b>
Kirim User ID yang ingin di-unblacklist:

<code>Contoh: 123456789</code>

📊 <b>CURRENT BLACKLIST</b>
└ Total: <code>${blacklistCount} user</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_viewuser" }
            ]
          ]
        }
      });
      
      userBlacklistSessions[chatId] = { action: "remove" };
      return;
    }

    // ADD PREMIUM TO USER
    if (data === "user_premium_add") {
      const caption = `<blockquote>💎 </blockquote>

📝 <b>TAMBAH PREMIUM</b>
Kirim User ID + Durasi:

<code>Format: user_id durasi</code>

<code>Contoh:</code>
• <code>123456789 7d</code> (7 hari)
• <code>123456789 30d</code> (30 hari)
• <code>123456789 1d</code> (1 hari)

💡 Durasi: d = hari, h = jam`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_viewuser" }
            ]
          ]
        }
      });
      
      userPremiumSessions[chatId] = { action: "add" };
      return;
    }

    // REMOVE PREMIUM FROM USER
    if (data === "user_premium_remove") {
      const dataObj = loadData();
      const premiumCount = Object.keys(dataObj.premium || {}).length;
      
      const caption = `<blockquote>❌</blockquote>

📝 <b>HAPUS PREMIUM</b>
Kirim User ID yang ingin dihapus premiumnya:

<code>Contoh: 123456789</code>

📊 <b>CURRENT PREMIUM</b>
└ Total: <code>${premiumCount} user</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_viewuser" }
            ]
          ]
        }
      });
      
      userPremiumSessions[chatId] = { action: "remove" };
      return;
    }

    // PREMIUM MANAGEMENT
    if (data === "setting_premium") {
      const dataObj = loadData();
      const premiumCount = Object.keys(dataObj.premium || {}).length;
      const now = Math.floor(Date.now() / 1000);
      let activePremium = 0;
      
      for (const userId in dataObj.premium) {
        if (dataObj.premium[userId] > now) {
          activePremium++;
        }
      }
      
      const caption = `<blockquote>💎</blockquote>

📊 <b>PREMIUM STATISTICS</b>
├ Total Premium: <code>${premiumCount}</code>
├ Active Premium: <code>${activePremium}</code>
├ Expired: <code>${premiumCount - activePremium}</code>
└ Premium Rate: <code>${((premiumCount / (dataObj.users?.length || 1)) * 100).toFixed(1)}%</code>

🔧 <b>MANAGEMENT TOOLS</b>
Pilih aksi di bawah:`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "➕ Add Premium", callback_data: "premium_add" },
              { text: "➖ Remove Premium", callback_data: "premium_remove" }
            ],
            [
              { text: "📋 List Premium", callback_data: "premium_list" },
              { text: "🔄 Check Expired", callback_data: "premium_check" }
            ],
            [
              { text: "🔙 Back", callback_data: "back_to_settings" }
            ]
          ]
        }
      });
      return;
    }

    // ADD PREMIUM
    if (data === "premium_add") {
      const caption = `<blockquote>💎 </blockquote>

📝 <b>TAMBAH PREMIUM</b>
Kirim User ID + Durasi:

<code>Format: user_id durasi</code>

<code>Contoh:</code>
• <code>123456789 7d</code> (7 hari)
• <code>123456789 30d</code> (30 hari)
• <code>123456789 1d</code> (1 hari)

💡 Durasi: d = hari, h = jam`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_premium" }
            ]
          ]
        }
      });
      
      userPremiumSessions[chatId] = { action: "add" };
      return;
    }

    // REMOVE PREMIUM
    if (data === "premium_remove") {
      const dataObj = loadData();
      const premiumCount = Object.keys(dataObj.premium || {}).length;
      
      const caption = `<blockquote>❌ </blockquote>

📝 <b>HAPUS PREMIUM</b>
Kirim User ID yang ingin dihapus premiumnya:

<code>Contoh: 123456789</code>

📊 <b>CURRENT PREMIUM</b>
└ Total: <code>${premiumCount} user</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_premium" }
            ]
          ]
        }
      });
      
      userPremiumSessions[chatId] = { action: "remove" };
      return;
    }

    // LIST PREMIUM
    if (data === "premium_list") {
      const dataObj = loadData();
      const premiumUsers = Object.keys(dataObj.premium || {});
      const now = Math.floor(Date.now() / 1000);
      
      if (premiumUsers.length === 0) {
        const caption = `<blockquote>📋 </blockquote>
❌ <b>Tidak ada user premium</b>`;

        await bot.editMessageText(caption, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: "🔄 Refresh", callback_data: "premium_list" }
              ],
              [
                { text: "🔙 Back", callback_data: "setting_premium" }
              ]
            ]
          }
        });
        return;
      }

      let premiumListText = "";
      let activeCount = 0;
      
      premiumUsers.slice(-10).reverse().forEach((userId, index) => {
        const isActive = dataObj.premium[userId] > now;
        const status = isActive ? "🟢" : "🔴";
        const expiry = isActive ? new Date(dataObj.premium[userId] * 1000).toLocaleDateString("id-ID") : "EXPIRED";
        
        if (isActive) activeCount++;
        
        premiumListText += `├ ${status} <code>${userId}</code> - ${expiry}\n`;
      });

      const caption = `<blockquote>📋 (10 Terbaru)</blockquote>

${premiumListText}
📊 <b>STATISTIK</b>
├ Total: <code>${premiumUsers.length}</code>
├ Aktif: <code>${activeCount}</code>
└ Expired: <code>${premiumUsers.length - activeCount}</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "premium_list" }
            ],
            [
              { text: "🔙 Back", callback_data: "setting_premium" }
            ]
          ]
        }
      });
      return;
    }

    // CHECK EXPIRED PREMIUM
    if (data === "premium_check") {
      const dataObj = loadData();
      const now = Math.floor(Date.now() / 1000);
      let expiredCount = 0;
      
      for (const userId in dataObj.premium) {
        if (dataObj.premium[userId] <= now) {
          expiredCount++;
        }
      }
      
      const caption = `<blockquote>🔄</blockquote>

📊 <b>HASIL CHECK</b>
├ Total Premium: <code>${Object.keys(dataObj.premium || {}).length}</code>
├ Expired: <code>${expiredCount}</code>
└ Status: ${expiredCount > 0 ? "⚠️ Ada premium expired" : "✅ Semua aktif"}

💡 Premium expired akan otomatis dihapus sistem`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🧹 Clean Expired", callback_data: "premium_clean" }
            ],
            [
              { text: "🔙 Back", callback_data: "setting_premium" }
            ]
          ]
        }
      });
      return;
    }

    // CLEAN EXPIRED PREMIUM
    if (data === "premium_clean") {
      const dataObj = loadData();
      const now = Math.floor(Date.now() / 1000);
      let cleanedCount = 0;
      
      for (const userId in dataObj.premium) {
        if (dataObj.premium[userId] <= now) {
          delete dataObj.premium[userId];
          cleanedCount++;
        }
      }
      
      saveData(dataObj);
      
      const caption = `<blockquote> </blockquote>

📊 <b>HASIL PEMBERSIHAN</b>
├ Premium dibersihkan: <code>${cleanedCount}</code>
├ Premium aktif: <code>${Object.keys(dataObj.premium || {}).length}</code>
└ Status: <code>✅ Berhasil</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "premium_list" }
            ],
            [
              { text: "🔙 Back", callback_data: "setting_premium" }
            ]
          ]
        }
      });
      return;
    }

    // OWNER MANAGEMENT
    if (data === "setting_owner") {
      const dataObj = loadData();
      const mainOwners = OWNER_IDS.length;
      const additionalOwners = dataObj.owner?.length || 0;
      const ceoCount = dataObj.ceo?.length || 0;
      
      const caption = `<blockquote>👑 </blockquote>

📊 <b>OWNER STATISTICS</b>
├ Main Owners: <code>${mainOwners}</code>
├ Additional Owners: <code>${additionalOwners}</code>
├ CEO: <code>${ceoCount}</code>
└ Total: <code>${mainOwners + additionalOwners + ceoCount}</code>

🔧 <b>MANAGEMENT TOOLS</b>
Pilih management di bawah:`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "👑 Add Owner", callback_data: "owner_add" },
              { text: "➖ Remove Owner", callback_data: "owner_remove" }
            ],
            [
              { text: "💼 Add Ceo", callback_data: "ceo_add" },
              { text: "➖ Remove Ceo", callback_data: "ceo_remove" }
            ],
            [
              { text: "📋 List Owners", callback_data: "owner_list" },
              { text: "📋 List Ceo", callback_data: "ceo_list" }
            ],
            [
              { text: "🔙 Back", callback_data: "back_to_settings" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "owner_add") {
      const caption = `<blockquote>👑 𝗔𝗗𝗗 𝗢𝗪𝗡𝗘𝗥</blockquote>

📝 <b>TAMBAH OWNER</b>
Kirim User ID yang ingin dijadikan owner:

<code>Contoh: 123456789</code>

⚠️ Owner akan memiliki akses penuh`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_owner" }
            ]
          ]
        }
      });
      
      ownerManagementSessions[chatId] = { action: "add_owner" };
      return;
    }

    if (data === "owner_remove") {
      const dataObj = loadData();
      const ownerCount = dataObj.owner?.length || 0;
      
      const caption = `<blockquote>➖ </blockquote>

📝 <b>HAPUS OWNER</b>
Kirim User ID yang ingin dihapus dari owner:

<code>Contoh: 123456789</code>

📊 <b>CURRENT OWNERS</b>
└ Total: <code>${ownerCount} owner</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_owner" }
            ]
          ]
        }
      });
      
      ownerManagementSessions[chatId] = { action: "remove_owner" };
      return;
    }

    if (data === "ceo_add") {
      const caption = `<blockquote>💼 </blockquote>

📝 <b>TAMBAH CEO</b>
Kirim User ID yang ingin dijadikan CEO:

<code>Contoh: 123456789</code>

⚠️ CEO akan memiliki akses tinggi`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_owner" }
            ]
          ]
        }
      });
      
      ceoManagementSessions[chatId] = { action: "add_ceo" };
      return;
    }

    if (data === "ceo_remove") {
      const dataObj = loadData();
      const ceoCount = dataObj.ceo?.length || 0;
      
      const caption = `<blockquote>➖</blockquote>

📝 <b>HAPUS CEO</b>
Kirim User ID yang ingin dihapus dari CEO:

<code>Contoh: 123456789</code>

📊 <b>CURRENT CEO</b>
└ Total: <code>${ceoCount} CEO</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_owner" }
            ]
          ]
        }
      });
      
      ceoManagementSessions[chatId] = { action: "remove_ceo" };
      return;
    }

    if (data === "owner_list") {
      const dataObj = loadData();
      const owners = dataObj.owner || [];
      const mainOwners = OWNER_IDS;
      
      let ownerListText = "";
      
      ownerListText += `👑 <b>MAIN OWNERS</b>\n`;
      mainOwners.forEach((ownerId, index) => {
        ownerListText += `├ ${index + 1}. <code>${ownerId}</code>\n`;
      });
      
      if (owners.length > 0) {
        ownerListText += `\n👥 <b>ADDITIONAL OWNERS</b>\n`;
        owners.forEach((ownerId, index) => {
          ownerListText += `├ ${index + 1}. <code>${ownerId}</code>\n`;
        });
      }
      
      const caption = `<blockquote>📋 </blockquote>

${ownerListText}
📊 <b>TOTAL</b>
└ Owners: <code>${mainOwners.length + owners.length}</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "owner_list" }
            ],
            [
              { text: "🔙 Back", callback_data: "setting_owner" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "ceo_list") {
      const dataObj = loadData();
      const ceos = dataObj.ceo || [];
      
      if (ceos.length === 0) {
        const caption = `<blockquote>📋 </blockquote>
❌ <b>Tidak ada CEO terdaftar</b>`;

        await bot.editMessageText(caption, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: "🔄 Refresh", callback_data: "ceo_list" }
              ],
              [
                { text: "🔙 Back", callback_data: "setting_owner" }
              ]
            ]
          }
        });
        return;
      }

      let ceoListText = ceos.map((ceoId, index) => {
        return `├ ${index + 1}. <code>${ceoId}</code>`;
      }).join("\n");

      const caption = `<blockquote>📋 </blockquote>

${ceoListText}
📊 <b>TOTAL</b>
└ CEO: <code>${ceos.length}</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "ceo_list" }
            ],
            [
              { text: "🔙 Back", callback_data: "setting_owner" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "setting_blacklist") {
      const dataObj = loadData();
      const blacklistCount = dataObj.blacklist?.length || 0;
      
      const caption = `<blockquote>🚫 </blockquote>

📊 <b>BLACKLIST STATISTICS</b>
├ Total Blacklisted: <code>${blacklistCount}</code>
├ Percentage: <code>${((blacklistCount / (dataObj.users?.length || 1)) * 100).toFixed(1)}%</code>
└ Clean Users: <code>${(dataObj.users?.length || 0) - blacklistCount}</code>

🔧 <b>MANAGEMENT TOOLS</b>
Pilih aksi di bawah:`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "➕ Add Blacklist", callback_data: "bl_add" },
              { text: "➖ Remove Blacklist", callback_data: "bl_remove" }
            ],
            [
              { text: "📋 List Blacklist", callback_data: "bl_list" },
              { text: "🧹 Clear All", callback_data: "bl_clear" }
            ],
            [
              { text: "🔙 Back", callback_data: "back_to_settings" }
            ]
          ]
        }
      });
      return;
    }
    
    if (data === "bl_add") {
      const caption = `<blockquote>🚫 </blockquote>

📝 <b>TAMBAH BLACKLIST</b>
Kirim User ID yang ingin di-blacklist:

<code>Contoh: 123456789</code>

⚠️ User akan diblokir dari menggunakan bot`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_blacklist" }
            ]
          ]
        }
      });
      
      userBlacklistSessions[chatId] = { action: "add" };
      return;
    }

    if (data === "bl_remove") {
      const dataObj = loadData();
      const blacklistCount = dataObj.blacklist?.length || 0;
      
      const caption = `<blockquote>✅ </blockquote>

📝 <b>HAPUS BLACKLIST</b>
Kirim User ID yang ingin di-unblacklist:

<code>Contoh: 123456789</code>

📊 <b>CURRENT BLACKLIST</b>
└ Total: <code>${blacklistCount} user</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_blacklist" }
            ]
          ]
        }
      });
      
      userBlacklistSessions[chatId] = { action: "remove" };
      return;
    }

    if (data === "bl_list") {
      const dataObj = loadData();
      const blacklist = dataObj.blacklist || [];
      
      if (blacklist.length === 0) {
        const caption = `<blockquote>📋 </blockquote>
✅ <b>Tidak ada user yang di-blacklist</b>`;

        await bot.editMessageText(caption, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: "🔄 Refresh", callback_data: "bl_list" }
              ],
              [
                { text: "🔙 Back", callback_data: "setting_blacklist" }
              ]
            ]
          }
        });
        return;
      }

      let blacklistText = blacklist.slice(-10).reverse().map((userId, index) => {
        return `├ ${index + 1}. <code>${userId}</code>`;
      }).join("\n");

      const caption = `<blockquote>📋  (10 Terbaru)</blockquote>

${blacklistText}
📊 <b>TOTAL</b>
└ Blacklisted: <code>${blacklist.length} user</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "bl_list" }
            ],
            [
              { text: "🔙 Back", callback_data: "setting_blacklist" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "bl_clear") {
      const dataObj = loadData();
      const blacklistCount = dataObj.blacklist?.length || 0;
      
      dataObj.blacklist = [];
      saveData(dataObj);
      
      const caption = `<blockquote> </blockquote>

📊 <b>HASIL PEMBERSIHAN</b>
├ Blacklist dihapus: <code>${blacklistCount}</code>
├ Status: <code>✅ Berhasil</code>
└ Semua user dapat akses kembali`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "bl_list" }
            ],
            [
              { text: "🔙 Back", callback_data: "setting_blacklist" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "setting_maintenance") {
      const maintenance = isMaintenance() ? "✅ AKTIF" : "❌ NONAKTIF";
      
      const caption = `<blockquote>🛠️ </blockquote>

📊 <b>STATUS MAINTENANCE</b>
├ Saat Ini: ${maintenance}
├ Fitur: Hanya owner yang bisa menggunakan
└ User: Tidak bisa menggunakan bot

🔧 <b>UBAH STATUS</b>
Pilih mode maintenance:`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✅ Aktifkan", callback_data: "maintenance_on" },
              { text: "❌ Nonaktifkan", callback_data: "maintenance_off" }
            ],
            [
              { text: "🔙 Back", callback_data: "back_to_settings" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "maintenance_on") {
      setMaintenance(true);
      
      const caption = `<blockquote>✅ </blockquote>

📊 <b>STATUS MAINTENANCE</b>
├ Saat Ini: ✅ AKTIF
├ Fitur: Hanya owner yang bisa menggunakan
└ User: Tidak bisa menggunakan bot

💡 Maintenance mode telah diaktifkan`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_maintenance" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "maintenance_off") {
      setMaintenance(false);
      
      const caption = `<blockquote>❌ </blockquote>

📊 <b>STATUS MAINTENANCE</b>
├ Saat Ini: ❌ NONAKTIF
├ Fitur: Semua user bisa menggunakan
└ User: Bisa menggunakan bot normal

💡 Maintenance mode telah dinonaktifkan`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_maintenance" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "setting_grouponly") {
      const dataObj = loadData();
      const grouponly = dataObj.settings?.grouponly ? "✅ AKTIF" : "❌ NONAKTIF";
      
      const caption = `<blockquote>👥 </blockquote>

📊 <b>STATUS GROUP ONLY</b>
├ Saat Ini: ${grouponly}
├ Fitur: Hanya bisa digunakan di grup
└ Private: Tidak bisa digunakan

🔧 <b>UBAH STATUS</b>
Pilih mode group only:`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✅ Aktifkan", callback_data: "grouponly_on" },
              { text: "❌ Nonaktifkan", callback_data: "grouponly_off" }
            ],
            [
              { text: "🔙 Back", callback_data: "back_to_settings" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "grouponly_on") {
      const dataObj = loadData();
      if (!dataObj.settings) dataObj.settings = {};
      dataObj.settings.grouponly = true;
      saveData(dataObj);
      
      const caption = `<blockquote>✅ </blockquote>

📊 <b>STATUS GROUP ONLY</b>
├ Saat Ini: ✅ AKTIF
├ Fitur: Hanya bisa digunakan di grup
└ Private: Tidak bisa digunakan

💡 Group Only mode telah diaktifkan`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_grouponly" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "grouponly_off") {
      const dataObj = loadData();
      if (!dataObj.settings) dataObj.settings = {};
      dataObj.settings.grouponly = false;
      saveData(dataObj);
      
      const caption = `<blockquote>❌ </blockquote>

📊 <b>STATUS GROUP ONLY</b>
├ Saat Ini: ❌ NONAKTIF
├ Fitur: Bisa digunakan di private chat
└ User: Bisa menggunakan di mana saja

💡 Group Only mode telah dinonaktifkan`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_grouponly" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "setting_stats") {
      const stats = generateSystemStats();
      
      const caption = `<blockquote>📊 </blockquote>

🌸 <b>STATISTIK</b>
├ Users: <code>${stats.totalUsers}</code>
├ Groups: <code>${stats.totalGroups}</code>  
├ Premium: <code>${stats.premiumUsers}</code>
└ Blacklist: <code>${stats.blacklistedUsers}</code>

⚡ <b>SISTEM</b>
├ Uptime: <code>${stats.uptime}</code>
├ Memory: <code>${stats.memoryUsage}</code>
├ Group Only: ${stats.groupOnly}
├ Maintenance: ${stats.maintenance}
└ Cooldown: <code>${stats.cooldown}m</code>

💡 <i>Statistik sistem real-time</i>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "setting_stats" }
            ],
            [
              { text: "🔙 Back", callback_data: "back_to_settings" }
            ]
          ]
        }
      });
      return;
    }
    
    if (data === "setting_reward") {
      const rewardSettings = getPremiumRewardSettings();
      const dataObj = loadData();
      const totalRewards = Object.keys(dataObj.user_group_count || {}).length;
      
      const caption = `<blockquote>🎁</blockquote>

📊 <b>SETTINGS SAAT INI</b>
├ Minimal Grup: <code>${rewardSettings.min_groups}</code>
├ Hari Premium: <code>${rewardSettings.days}</code>
└ Total User Reward: <code>${totalRewards}</code>

💡 <b>KETERANGAN SISTEM</b>
• User dapat premium dengan menambahkan bot ke grup
• Minimal ${rewardSettings.min_groups} grup untuk dapat ${rewardSettings.days} hari premium
• Setiap grup minimal 5 member

🔧 <b>UBAH PENGATURAN</b>
Pilih yang ingin diubah:`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "📊 Set Minimal Grup", callback_data: "reward_set_groups" },
              { text: "⏰ Set Hari Premium", callback_data: "reward_set_days" }
            ],
            [
              { text: "📋 List User Reward", callback_data: "reward_list_users" },
              { text: "🔄 Reset Reward", callback_data: "reward_reset" }
            ],
            [
              { text: "🔙 Back", callback_data: "back_to_settings" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "reward_set_groups") {
      const rewardSettings = getPremiumRewardSettings();
      
      const caption = `<blockquote>📊 </blockquote>

📝 <b>SET MINIMAL GRUP</b>
Saat ini: <code>${rewardSettings.min_groups} grup</code>

Kirim angka minimal grup untuk mendapatkan premium:

<code>Contoh: 1</code> (1 grup)
<code>Contoh: 2</code> (2 grup)

⚠️ Minimal: 1 grup`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_reward" }
            ]
          ]
        }
      });
      
      rewardSessions[chatId] = { action: "set_groups" };
      return;
    }

    if (data === "reward_set_days") {
      const rewardSettings = getPremiumRewardSettings();
      
      const caption = `<blockquote>⏰ </blockquote>

📝 <b>SET HARI PREMIUM</b>
Saat ini: <code>${rewardSettings.days} hari</code>

Kirim jumlah hari premium yang diberikan:

<code>Contoh: 7</code> (7 hari)
<code>Contoh: 30</code> (30 hari)

⚠️ Minimal: 1 hari`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_reward" }
            ]
          ]
        }
      });
      
      rewardSessions[chatId] = { action: "set_days" };
      return;
    }

    if (data === "reward_list_users") {
      const dataObj = loadData();
      const userGroups = dataObj.user_group_count || {};
      
      if (Object.keys(userGroups).length === 0) {
        const caption = `<blockquote>📋 </blockquote>
❌ <b>Tidak ada user yang mendapatkan reward</b>`;

        await bot.editMessageText(caption, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: "🔄 Refresh", callback_data: "reward_list_users" }
              ],
              [
                { text: "🔙 Back", callback_data: "setting_reward" }
              ]
            ]
          }
        });
        return;
      }

      let userListText = "";
      let count = 0;
      
      Object.keys(userGroups).slice(-10).reverse().forEach(userId => {
        count++;
        const groups = userGroups[userId];
        userListText += `├ ${count}. <code>${userId}</code> - ${groups} grup\n`;
      });

      const caption = `<blockquote>📋  (10 Terbaru)</blockquote>

${userListText}
📊 <b>TOTAL</b>
└ User: <code>${Object.keys(userGroups).length}</code>`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "reward_list_users" }
            ],
            [
              { text: "🔙 Back", callback_data: "setting_reward" }
            ]
          ]
        }
      });
      return;
    }

    if (data === "reward_reset") {
      const caption = `<blockquote>🔄 </blockquote>

⚠️ <b>KONFIRMASI RESET</b>
Anda akan mereset semua data reward user:

• User group count
• History reward

Data premium user TIDAK akan direset.

Apakah Anda yakin?`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✅ Ya, Reset", callback_data: "reward_confirm_reset" },
              { text: "❌ Cancel", callback_data: "setting_reward" }
            ]
          ]
        }
      });
      return;
    }
    
    if (data === "reward_confirm_reset") {
      const dataObj = loadData();
      const userCount = Object.keys(dataObj.user_group_count || {}).length;
      
      dataObj.user_group_count = {};
      saveData(dataObj);
      
      const caption = `<blockquote>✅ </blockquote>

📊 <b>HASIL RESET</b>
├ Data direset: <code>${userCount} user</code>
├ Status: <code>✅ Berhasil</code>
└ Semua user bisa mulai dari 0 lagi`;

      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔙 Back", callback_data: "setting_reward" }
            ]
          ]
        }
      });
      return;
    }

  } catch (error) {
    console.error("Error callback setting:", error);
    await bot.answerCallbackQuery(query.id, { text: "❌ Error terjadi", show_alert: true });
  }
});

bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;
  
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const text = msg.text.trim();

  if (userSearchSessions[chatId]?.waitingForInput) {
    delete userSearchSessions[chatId];
    
    let searchId = text.replace('@', '');
    if (!isNaN(searchId)) {
      searchId = searchId.toString();
    }

    const dataObj = loadData();
    const users = dataObj.users || [];
    
    let foundUser = null;
    if (users.includes(searchId)) {
      foundUser = searchId;
    }

    if (foundUser) {
      const isPremium = dataObj.premium?.[foundUser] && dataObj.premium[foundUser] > Math.floor(Date.now() / 1000);
      const isBlacklisted = dataObj.blacklist?.includes(foundUser);
      const premiumExpiry = isPremium ? new Date(dataObj.premium[foundUser] * 1000).toLocaleString("id-ID") : "Tidak ada";
      
      const caption = `<blockquote>✅ </blockquote>

👤 <b>USER INFORMATION</b>
├ User ID: <code>${foundUser}</code>
├ Premium: ${isPremium ? "✅ Aktif" : "❌ Nonaktif"}
├ Blacklisted: ${isBlacklisted ? "✅ Ya" : "❌ Tidak"}
${isPremium ? `└ Premium Expiry: <code>${premiumExpiry}</code>` : '└ Status: <code>User Biasa</code>'}

🔧 <b>QUICK ACTIONS</b>
Kelola user dengan button di bawah`;

      await bot.sendMessage(chatId, caption, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🚫 Blacklist", callback_data: `quick_bl_${foundUser}` },
              { text: "✅ Unblacklist", callback_data: `quick_unbl_${foundUser}` }
            ],
            [
              { text: "💎 Add Premium", callback_data: `quick_premium_${foundUser}` },
              { text: "❌ Remove Premium", callback_data: `quick_nopremium_${foundUser}` }
            ]
          ]
        }
      });
    } else {
      await bot.sendMessage(chatId, `<blockquote>❌ </blockquote>
User dengan ID/Username <code>${text}</code> tidak ditemukan di database.`, { parse_mode: 'HTML' });
    }
    return;
  }
  
  if (userBlacklistSessions[chatId]) {
    const action = userBlacklistSessions[chatId].action;
    delete userBlacklistSessions[chatId];

    const targetId = text.replace('@', '');
    if (!targetId || isNaN(targetId)) {
      return bot.sendMessage(chatId, `<blockquote>❌ </blockquote>
User ID harus berupa angka.`, { parse_mode: 'HTML' });
    }

    const dataObj = loadData();
    if (!dataObj.blacklist) dataObj.blacklist = [];

    if (action === "add") {
      if (dataObj.blacklist.includes(targetId)) {
        await bot.sendMessage(chatId, `<blockquote>⚠️ </blockquote>
User <code>${targetId}</code> sudah ada di blacklist.`, { parse_mode: 'HTML' });
      } else {
        dataObj.blacklist.push(targetId);
        saveData(dataObj);
        await bot.sendMessage(chatId, `<blockquote>✅ </blockquote>
User <code>${targetId}</code> berhasil ditambahkan ke blacklist.`, { parse_mode: 'HTML' });
      }
    } else if (action === "remove") {
      if (!dataObj.blacklist.includes(targetId)) {
        await bot.sendMessage(chatId, `<blockquote>⚠️ </blockquote>
User <code>${targetId}</code> tidak ditemukan di blacklist.`, { parse_mode: 'HTML' });
      } else {
        dataObj.blacklist = dataObj.blacklist.filter(id => id !== targetId);
        saveData(dataObj);
        await bot.sendMessage(chatId, `<blockquote>✅ </blockquote>
User <code>${targetId}</code> berhasil dihapus dari blacklist.`, { parse_mode: 'HTML' });
      }
    }
    return;
  }

  if (userPremiumSessions[chatId]) {
    const action = userPremiumSessions[chatId].action;
    delete userPremiumSessions[chatId];

    if (action === "add") {
      const [targetId, durationStr] = text.split(' ');
      if (!targetId || !durationStr) {
        return bot.sendMessage(chatId, `<blockquote>❌ </blockquote>
Gunakan format: <code>user_id durasi</code>
Contoh: <code>123456789 7d</code>`, { parse_mode: 'HTML' });
      }

      const duration = parseInt(durationStr);
      const unit = durationStr.slice(-1).toLowerCase();
      let seconds = 0;

      if (unit === 'd') {
        seconds = duration * 86400;
      } else if (unit === 'h') {
        seconds = duration * 3600;
      } else {
        return bot.sendMessage(chatId, `<blockquote>❌ </blockquote>
Gunakan d (hari) atau h (jam) sebagai unit.`, { parse_mode: 'HTML' });
      }

      const dataObj = loadData();
      if (!dataObj.premium) dataObj.premium = {};
      const now = Math.floor(Date.now() / 1000);
      const current = dataObj.premium[targetId] || now;
      dataObj.premium[targetId] = current > now ? current + seconds : now + seconds;
      saveData(dataObj);

      const expiryDate = new Date(dataObj.premium[targetId] * 1000).toLocaleString("id-ID");
      await bot.sendMessage(chatId, `<blockquote>💎 </blockquote>
User <code>${targetId}</code> berhasil diberi premium ${duration}${unit}.
Berlaku sampai: <code>${expiryDate}</code>`, { parse_mode: 'HTML' });

    } else if (action === "remove") {
      const targetId = text;
      const dataObj = loadData();
      
      if (!dataObj.premium?.[targetId]) {
        await bot.sendMessage(chatId, `<blockquote>⚠️ </blockquote>
User <code>${targetId}</code> tidak memiliki akses premium.`, { parse_mode: 'HTML' });
      } else {
        delete dataObj.premium[targetId];
        saveData(dataObj);
        await bot.sendMessage(chatId, `<blockquote>❌</blockquote>
Akses premium untuk user <code>${targetId}</code> berhasil dihapus.`, { parse_mode: 'HTML' });
      }
    }
    return;
  }

  if (ownerManagementSessions[chatId]) {
    const action = ownerManagementSessions[chatId].action;
    delete ownerManagementSessions[chatId];

    const targetId = text;
    if (!targetId || isNaN(targetId)) {
      return bot.sendMessage(chatId, `<blockquote>❌ </blockquote>
User ID harus berupa angka.`, { parse_mode: 'HTML' });
    }

    const dataObj = loadData();
    if (!dataObj.owner) dataObj.owner = [];

    if (action === "add_owner") {
      if (dataObj.owner.includes(targetId)) {
        await bot.sendMessage(chatId, `<blockquote>⚠️ </blockquote>
User <code>${targetId}</code> sudah menjadi owner.`, { parse_mode: 'HTML' });
      } else {
        dataObj.owner.push(targetId);
        saveData(dataObj);
        await bot.sendMessage(chatId, `<blockquote>👑 </blockquote>
User <code>${targetId}</code> berhasil dijadikan owner.`, { parse_mode: 'HTML' });
      }
    } else if (action === "remove_owner") {
      if (!dataObj.owner.includes(targetId)) {
        await bot.sendMessage(chatId, `<blockquote>⚠️ </blockquote>
User <code>${targetId}</code> bukan owner tambahan.`, { parse_mode: 'HTML' });
      } else {
        dataObj.owner = dataObj.owner.filter(id => id !== targetId);
        saveData(dataObj);
        await bot.sendMessage(chatId, `<blockquote>➖ 𝗢𝗪𝗡𝗘𝗥 𝗗𝗜𝗛𝗔𝗣𝗨𝗦</blockquote>
User <code>${targetId}</code> berhasil dihapus dari owner.`, { parse_mode: 'HTML' });
      }
    }
    return;
  }

  if (ceoManagementSessions[chatId]) {
    const action = ceoManagementSessions[chatId].action;
    delete ceoManagementSessions[chatId];

    const targetId = text;
    if (!targetId || isNaN(targetId)) {
      return bot.sendMessage(chatId, `<blockquote>❌ </blockquote>
User ID harus berupa angka.`, { parse_mode: 'HTML' });
    }

    const dataObj = loadData();
    if (!dataObj.ceo) dataObj.ceo = [];

    if (action === "add_ceo") {
      if (dataObj.ceo.includes(targetId)) {
        await bot.sendMessage(chatId, `<blockquote>⚠️ </blockquote>
User <code>${targetId}</code> sudah menjadi CEO.`, { parse_mode: 'HTML' });
      } else {
        dataObj.ceo.push(targetId);
        saveData(dataObj);
        await bot.sendMessage(chatId, `<blockquote>💼 </blockquote>
User <code>${targetId}</code> berhasil dijadikan CEO.`, { parse_mode: 'HTML' });
      }
    } else if (action === "remove_ceo") {
      if (!dataObj.ceo.includes(targetId)) {
        await bot.sendMessage(chatId, `<blockquote>⚠️ </blockquote>
User <code>${targetId}</code> bukan CEO.`, { parse_mode: 'HTML' });
      } else {
        dataObj.ceo = dataObj.ceo.filter(id => id !== targetId);
        saveData(dataObj);
        await bot.sendMessage(chatId, `<blockquote>➖</blockquote>
User <code>${targetId}</code> berhasil dihapus dari CEO.`, { parse_mode: 'HTML' });
      }
    }
    return;
  }

  if (rewardSessions[chatId]) {
    const action = rewardSessions[chatId].action;
    delete rewardSessions[chatId];

    const value = parseInt(text);
    
    if (isNaN(value) || value < 1) {
      return bot.sendMessage(chatId, `<blockquote>❌ </blockquote>
Harap masukkan angka yang valid (minimal 1).`, { parse_mode: 'HTML' });
    }

    const rewardSettings = getPremiumRewardSettings();
    
    if (action === "set_groups") {
      setPremiumRewardSettings(value, rewardSettings.days);
      await bot.sendMessage(chatId, `<blockquote>✅ </blockquote>
Minimal grup diubah menjadi: <code>${value} grup</code>
User membutuhkan ${value} grup untuk mendapatkan premium ${rewardSettings.days} hari.`, { parse_mode: 'HTML' });
    
    } else if (action === "set_days") {
      setPremiumRewardSettings(rewardSettings.min_groups, value);
      await bot.sendMessage(chatId, `<blockquote>✅ </blockquote>
Hari premium diubah menjadi: <code>${value} hari</code>
User akan mendapatkan ${value} hari premium untuk ${rewardSettings.min_groups} grup.`, { parse_mode: 'HTML' });
    }
    
    bot.emit("callback_query", { 
      ...msg, 
      data: "setting_reward",
      message: { chat: { id: chatId }, message_id: msg.message_id }
    });
    return;
  }
});

function getPremiumRewardSettings() {
  const data = loadData();
  if (!data.settings) data.settings = {};
  if (!data.settings.premium_reward) {
    data.settings.premium_reward = {
      min_groups: 1,
      days: 7
    };
    saveData(data);
  }
  return data.settings.premium_reward;
}

function setPremiumRewardSettings(minGroups, days) {
  const data = loadData();
  if (!data.settings) data.settings = {};
  data.settings.premium_reward = {
    min_groups: parseInt(minGroups),
    days: parseInt(days)
  };
  saveData(data);
  return data.settings.premium_reward;
}

function isMaintenance() {
  const data = loadData();
  return data.settings?.maintenance === true;
}

function setMaintenance(state) {
  const data = loadData();
  if (!data.settings) data.settings = {};
  data.settings.maintenance = state;
  saveData(data);
}

function getGlobalCooldownMinutes() {
  const data = loadData();
  return data.settings?.cooldown?.default || 15;
}

function generateSystemStats() {
  const data = loadData();
  const settings = data.settings || {};
  const memoryUsage = process.memoryUsage();
  const usedMemory = Math.round(memoryUsage.heapUsed / 1024 / 1024);
  
  return {
    totalUsers: data.users?.length || 0,
    totalGroups: data.groups?.length || 0,
    premiumUsers: Object.keys(data.premium || {}).length,
    blacklistedUsers: data.blacklist?.length || 0,
    uptime: Waktu(),
    memoryUsage: `${usedMemory}MB`,
    groupOnly: settings.grouponly ? "✅" : "❌",
    maintenance: settings.maintenance ? "✅" : "❌",
    cooldown: settings.cooldown?.default || 15
  };
}

function Waktu() {
  const uptime = process.uptime();
  const hours = Math.floor(uptime / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = Math.floor(uptime % 60);
  return `${hours}h ${minutes}m ${seconds}s`;
}

// === /update ===
bot.onText(/^\/update$/, async (msg) => {
  if (!(await cekAkses("utama", msg))) return;

  const chatId = msg.chat.id;
  const username = msg.from.first_name || "User";

  if (!msg.reply_to_message || !msg.reply_to_message.document) {
    return bot.sendMessage(chatId, `
<blockquote>⚙️ </blockquote>

🌸 <b>Cara menggunakan:</b>
➥ <b>1.</b> Kirim file <code>JS</code>  
➥ <b>2.</b> Reply file tersebut dengan perintah <code>/update</code>

👋 Hai <b>${username}</b> 🌸`, { parse_mode: "HTML" });
  }

  const file = msg.reply_to_message.document;
  const fileId = file.file_id;
  const fileName = file.file_name || "update.js";

  if (!fileName.endsWith(".js")) {
    return bot.sendMessage(chatId, `
<blockquote>❌ </blockquote>
➥ <b>File:</b> <code>${fileName}</code>
➥ <b>Status:</b> File harus berekstensi .js`, { parse_mode: "HTML" });
  }

  const tempFile = "./temp_update.js";
  const currentPath = path.resolve(__filename);
  let loadingMessage;

  try {
    loadingMessage = await bot.sendMessage(chatId, `
<blockquote>🔄 </blockquote>
➥ <b>Status:</b> Sedang mengunduh file pembaruan...
➥ <b>File:</b> <code>${fileName}</code>`, { parse_mode: "HTML" });
    
    const fileLink = await bot.getFileLink(fileId);

    const frames = ["🔄", "⏳", "🌀", "💫"];
    let frameIndex = 0;
    
    const loadingInterval = setInterval(async () => {
      try {
        await bot.editMessageText(
          `<blockquote>${frames[frameIndex]} </blockquote>
➥ <b>Status:</b> Sedang memproses update...
➥ <b>File:</b> <code>${fileName}</code>`,
          {
            chat_id: chatId,
            message_id: loadingMessage.message_id,
            parse_mode: "HTML"
          }
        );
        frameIndex = (frameIndex + 1) % frames.length;
      } catch (err) {}
    }, 1500);

    const response = await axios({
      method: "GET",
      url: fileLink,
      responseType: "stream",
      timeout: 30000,
    });

    const writer = fs.createWriteStream(tempFile);
    response.data.pipe(writer);

    writer.on("finish", async () => {
      clearInterval(loadingInterval);
      
      try {
        const { size } = fs.statSync(tempFile);
        const sizeKB = (size / 1024).toFixed(2);

        await bot.editMessageText(`
<blockquote>✅ </blockquote>
➥ <b>Status:</b> Memulai proses update sistem...
➥ <b>File:</b> <code>${fileName}</code>`, {
          chat_id: chatId,
          message_id: loadingMessage.message_id,
          parse_mode: "HTML"
        });

        fs.unlinkSync(currentPath);
        fs.renameSync(tempFile, currentPath);

        await bot.editMessageText(`
<blockquote>✅ </blockquote>

🌸 <b>Detail Update</b>
➥ <b>File:</b> <code>${fileName}</code>  
➥ <b>Ukuran:</b> ${sizeKB} KB  
➥ <b>Oleh:</b> ${username}  
➥ <b>Waktu:</b> ${new Date().toLocaleString("id-ID")}

⚠️ <b>Bot akan restart otomatis dalam 3 detik...</b>`, {
          chat_id: chatId,
          message_id: loadingMessage.message_id,
          parse_mode: "HTML",
        });

        setTimeout(async () => {
          await bot.editMessageText(`
<blockquote>♻️ </blockquote>

🌸 <b>Detail Update</b>
➥ <b>File:</b> <code>${fileName}</code>  
➥ <b>Ukuran:</b> ${sizeKB} KB  
➥ <b>Oleh:</b> ${username}  
➥ <b>Waktu:</b> ${new Date().toLocaleString("id-ID")}
➥ <b>Status:</b> ✅ Bot berhasil diperbarui!`, {
            chat_id: chatId,
            message_id: loadingMessage.message_id,
            parse_mode: "HTML",
          });
        }, 2000);

        setTimeout(() => {
          console.log(chalk.hex("#FF4500").bold("[ Restarting Bot... ]"));
          process.exit(0);
        }, 3000);

      } catch (err) {
        clearInterval(loadingInterval);
        console.error("❌ Gagal saat update:", err);
        await bot.editMessageText(`
<blockquote>❌</blockquote>
➥ <b>Error:</b> Terjadi kesalahan saat mengganti file bot
➥ <b>Solusi:</b> Pastikan bot punya izin tulis di folder ini`, {
          chat_id: chatId,
          message_id: loadingMessage.message_id,
          parse_mode: "HTML"
        });
      }
    });

    writer.on("error", async (err) => {
      clearInterval(loadingInterval);
      console.error("❌ Gagal menulis file:", err);
      await bot.editMessageText(`
<blockquote>❌ </blockquote>
➥ <b>Error:</b> Terjadi error saat menulis file update
➥ <b>Solusi:</b> Pastikan koneksi stabil lalu coba ulang`, {
        chat_id: chatId,
        message_id: loadingMessage.message_id,
        parse_mode: "HTML"
      });
    });

  } catch (err) {
    console.error("❌ Error update:", err);
    if (loadingMessage) {
      await bot.editMessageText(`
<blockquote>❌ </blockquote>
➥ <b>Error:</b> Terjadi error tidak terduga
➥ <b>Solusi:</b> Pastikan file JS valid dan coba lagi`, {
        chat_id: chatId,
        message_id: loadingMessage.message_id,
        parse_mode: "HTML"
      });
    } else {
      await bot.sendMessage(chatId, `
<blockquote>❌ </blockquote>
➥ <b>Error:</b> Terjadi error tidak terduga
➥ <b>Solusi:</b> Pastikan file JS valid dan coba lagi`, { parse_mode: "HTML" });
    }
  }
});

// === /deposit === 
bot.onText(/^\/deposit$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  depositSessions[userId] = { waitingForCustomAmount: true };

  const text = `
<blockquote>💳 </blockquote>

💰 <b>Pilih Nominal Deposit:</b>
➥ Deposit cepat dengan nominal yang tersedia

<code>────────────────────</code>
💠 <b>Minimal Deposit:</b> Rp ${PAYMENT_SETTINGS.MIN_DEPOSIT.toLocaleString('id-ID')}
  `;

  await bot.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '💰 10K', callback_data: 'deposit_10000' },
          { text: '💰 25K', callback_data: 'deposit_25000' },
          { text: '💰 50K', callback_data: 'deposit_50000' }
        ],
        [
          { text: '💰 100K', callback_data: 'deposit_100000' },
          { text: '💰 250K', callback_data: 'deposit_250000' },
          { text: '💰 500K', callback_data: 'deposit_500000' }
        ],
        [
          { text: '📝 Custom Amount', callback_data: 'deposit_custom' }
        ],
        [
          { text: '💳 Cek Saldo', callback_data: 'cek_saldo' },
          { text: '🛍️ Lihat Produk', callback_data: 'lihat_produk' }
        ]
      ]
    }
  });
});

// === /ceksaldo === 
bot.onText(/^\/ceksaldo$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const user = initializeUser(userId, msg.from);
  
  const text = `
<blockquote>💳 </blockquote>

👤 <b>User:</b> ${msg.from.first_name}
💰 <b>Saldo:</b> <code>Rp ${user.balance.toLocaleString('id-ID')}</code>
📅 <b>Update:</b> ${new Date().toLocaleString('id-ID')}

<code>────────────────────</code>
💎 <i>Saldo dapat digunakan untuk membeli produk</i>
  `;

  await bot.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '💳 Deposit', callback_data: 'deposit_menu' },
          { text: '🛍️ Beli Produk', callback_data: 'lihat_produk' }
        ],
        [
          { text: '🔄 Refresh Saldo', callback_data: 'refresh_saldo' }
        ]
      ]
    }
  });
});

// === /stock === 
bot.onText(/^\/stock$/, async (msg) => {
  await showStockList(msg.chat.id, null, msg.from);
});

// === /buy === 
bot.onText(/^\/buy$/, async (msg) => {
  await showStockList(msg.chat.id, null, msg.from);
});

// === SHOW STOCK LIST FUNCTION ===
async function showStockList(chatId, messageId = null, userInfo = null) {
  const products = Object.values(productDB.products);
  const availableProducts = products.filter(p => p.stock > 0);
  
  if (availableProducts.length === 0) {
    const text = `
<blockquote>📦 </blockquote>

😔 <b>Maaf, semua produk sedang habis</b>
➥ <b>Status:</b> Stok kosong
➥ <b>Total Produk:</b> ${products.length} produk
➥ <b>Produk Tersedia:</b> 0 produk

<code>────────────────────</code>
📞 <i>Silakan hubungi admin untuk info restock</i>
    `;
    
    if (messageId) {
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '🔄 Refresh Stok', callback_data: 'refresh_stock' },
                { text: '💳 Deposit', callback_data: 'deposit_menu' }
              ],
              [
                { text: '💳 Cek Saldo', callback_data: 'cek_saldo' }
              ]
            ]
          }
        });
      } catch (error) {
        await bot.sendMessage(chatId, text, { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '🔄 Refresh Stok', callback_data: 'refresh_stock' },
                { text: '💳 Deposit', callback_data: 'deposit_menu' }
              ],
              [
                { text: '💳 Cek Saldo', callback_data: 'cek_saldo' }
              ]
            ]
          }
        });
      }
    } else {
      await bot.sendMessage(chatId, text, { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔄 Refresh Stok', callback_data: 'refresh_stock' },
              { text: '💳 Deposit', callback_data: 'deposit_menu' }
            ],
            [
              { text: '💳 Cek Saldo', callback_data: 'cek_saldo' }
            ]
          ]
        }
      });
    }
    return;
  }

  const keyboard = [];
 
  for (let i = 0; i < availableProducts.length; i += 2) {
    const row = [];
    if (availableProducts[i]) {
      const status = availableProducts[i].stock <= 5 ? '🟡' : '🟢';
      row.push({
        text: `${status} ${availableProducts[i].name}`,
        callback_data: `product_${availableProducts[i].id}`
      });
    }
    if (availableProducts[i + 1]) {
      const status = availableProducts[i + 1].stock <= 5 ? '🟡' : '🟢';
      row.push({
        text: `${status} ${availableProducts[i + 1].name}`,
        callback_data: `product_${availableProducts[i + 1].id}`
      });
    }
    keyboard.push(row);
  }

  keyboard.push([
    { text: '🔄 Refresh', callback_data: 'refresh_stock' }
  ]);
  keyboard.push([
    { text: '💳 Deposit', callback_data: 'deposit_menu' },
    { text: '💰 Cek Saldo', callback_data: 'cek_saldo' }
  ]);

  const totalProducts = products.length;
  const totalStock = availableProducts.reduce((sum, p) => sum + p.stock, 0);
  const outOfStock = products.length - availableProducts.length;

  const text = `
<blockquote>🛍️ </blockquote>

📊 <b>Statistik Toko:</b>
➥ <b>Total Produk:</b> ${totalProducts}
➥ <b>Produk Ready:</b> ${availableProducts.length}
➥ <b>Stok Tersedia:</b> ${totalStock} item
➥ <b>Produk Habis:</b> ${outOfStock}

<code>────────────────────</code>
🟢 <b>Tersedia</b> | 🟡 <b>Menipis</b>
➥ <b>Klik produk untuk membeli</b>
  `;

  if (messageId) {
    try {
      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: keyboard }
      });
    } catch (error) {
      await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: keyboard }
      });
    }
  } else {
    await bot.sendMessage(chatId, text, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });
  }
}

// === SHOW PRODUCT DETAIL FUNCTION ===
async function showProductDetail(chatId, userId, productId, messageId = null) {
  const product = productDB.products[productId];
  if (!product) {
    const text = `
<blockquote>❌ </blockquote>
➥ <b>Status:</b> Produk tidak ditemukan
    `;
    
    if (messageId) {
      try {
        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '📋 Kembali ke List', callback_data: 'kembali_list' }]
            ]
          }
        });
      } catch (error) {
        await bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
      }
    } else {
      await bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
    }
    return;
  }

  const user = initializeUser(userId);
  const status = product.stock === 0 ? '🔴 HABIS' : 
                product.stock <= 5 ? '🟡 MENIPIS' : '🟢 TERSEDIA';

  const text = `
<blockquote>📋 </blockquote>

🏷️ <b>Nama:</b> ${product.name}
🆔 <b>ID:</b> <code>${product.id}</code>
💰 <b>Harga:</b> <code>Rp ${product.price.toLocaleString('id-ID')}</code>
📦 <b>Stok:</b> ${product.stock} unit
🎯 <b>Status:</b> ${status}

<code>────────────────────</code>
📝 <b>Deskripsi:</b>
${product.description}

<code>────────────────────</code>
👤 <b>Saldo Anda:</b> <code>Rp ${user.balance.toLocaleString('id-ID')}</code>
  `;

  const keyboard = [];
  
  if (product.stock > 0) {
  
    const maxQty = Math.min(product.stock, 4);
    for (let i = 1; i <= maxQty; i += 2) {
      const row = [];
      row.push({
        text: `🛒 ${i} Unit`,
        callback_data: `buy_${productId}_${i}`
      });
      if (i + 1 <= maxQty) {
        row.push({
          text: `🛒 ${i + 1} Unit`,
          callback_data: `buy_${productId}_${i + 1}`
        });
      }
      keyboard.push(row);
    }
  } else {
    keyboard.push([
      { text: '🔴 Stok Habis', callback_data: 'stok_habis' }
    ]);
  }

  keyboard.push([
    { text: '📋 Kembali', callback_data: 'kembali_list' }
  ]);
  keyboard.push([
    { text: '💳 Deposit', callback_data: 'deposit_menu' },
    { text: '💰 Saldo', callback_data: 'cek_saldo' }
  ]);

  if (messageId) {
    try {
      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: keyboard }
      });
    } catch (error) {
      await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: keyboard }
      });
    }
  } else {
    await bot.sendMessage(chatId, text, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });
  }
}

// === PROCESS BUY FUNCTION ===
async function processBuy(chatId, userId, productId, qty, userInfo, messageId = null) {
  const user = initializeUser(userId, userInfo);
  const product = productDB.products[productId];
  
  if (!product) {
    const text = `
<blockquote>❌ </blockquote>
➥ <b>Status:</b> Produk tidak ditemukan
    `;

    if (messageId) {
      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML'
      });
    } else {
      await bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
    }
    return;
  }

  if (product.stock < qty) {
    const text = `
<blockquote>⚠️ </blockquote>
➥ <b>Stok Tersedia:</b> ${product.stock}
➥ <b>Yang Dibutuhkan:</b> ${qty}
    `;

    if (messageId) {
      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '📋 Kembali', callback_data: `product_${productId}` }]
          ]
        }
      });
    } else {
      await bot.sendMessage(chatId, text, { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '📋 Kembali', callback_data: `product_${productId}` }]
          ]
        }
      });
    }
    return;
  }

  const total = product.price * qty;
  if (user.balance < total) {
    const text = `
<blockquote>💳 </blockquote>
➥ <b>Total:</b> <code>Rp ${total.toLocaleString('id-ID')}</code>
➥ <b>Saldo Kamu:</b> <code>Rp ${user.balance.toLocaleString('id-ID')}</code>

<code>────────────────────</code>
💎 <i>Silakan deposit terlebih dahulu</i>
    `;

    if (messageId) {
      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '💳 Deposit', callback_data: 'deposit_menu' },
              { text: '📋 Kembali', callback_data: `product_${productId}` }
            ]
          ]
        }
      });
    } else {
      await bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '💳 Deposit', callback_data: 'deposit_menu' },
              { text: '📋 Kembali', callback_data: `product_${productId}` }
            ]
          ]
        }
      });
    }
    return;
  }

  const orderId = `ORD-${Date.now().toString().slice(-8)}`;
  user.balance -= total;
  product.stock -= qty;

  productDB.orders[orderId] = {
    id: orderId,
    user_id: userId,
    product_id: productId,
    qty,
    total,
    created_at: new Date().toISOString()
  };
  saveProductData(); // SIMPAN KE PRODUCT_FILE

  const successText = `
<blockquote>✅ </blockquote>

🎉 <b>Terima kasih telah berbelanja!</b>
➥ <b>ID Order:</b> <code>${orderId}</code>
➥ <b>Produk:</b> ${product.name}
➥ <b>Jumlah:</b> ${qty} unit
➥ <b>Total:</b> <code>Rp ${total.toLocaleString('id-ID')}</code>
➥ <b>Sisa Saldo:</b> <code>Rp ${user.balance.toLocaleString('id-ID')}</code>

<code>────────────────────</code>
📦 <i>File produk sedang dikirim...</i>
  `;

  if (messageId) {
    await bot.editMessageText(successText, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🛍️ Beli Lagi', callback_data: 'lihat_produk' },
            { text: '💳 Deposit', callback_data: 'deposit_menu' }
          ]
        ]
      }
    });
  } else {
    await bot.sendMessage(chatId, successText, { 
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🛍️ Beli Lagi', callback_data: 'lihat_produk' },
            { text: '💳 Deposit', callback_data: 'deposit_menu' }
          ]
        ]
      }
    });
  }

  try {
    await bot.sendDocument(chatId, product.fileId, {
      caption: `
📦 <b>File Produk:</b> ${product.name}
✅ <b>Status:</b> Berhasil dikirim
🎯 <b>Selamat menikmati!</b>
      `,
      parse_mode: 'HTML'
    });
  } catch (error) {
    await bot.sendMessage(chatId, `
⚠️ <b>File sedang diproses</b>
➥ Admin akan mengirimkan file segera
➥ ID Order: <code>${orderId}</code>
    `, { parse_mode: 'HTML' });
  }

  await bot.sendMessage(OWNER_IDS[0], `
<blockquote>🛒 </blockquote>
➥ <b>User:</b> ${userInfo.first_name}
➥ <b>Produk:</b> ${product.name}
➥ <b>Jumlah:</b> ${qty} unit
➥ <b>Total:</b> <code>Rp ${total.toLocaleString('id-ID')}</code>
➥ <b>ID Order:</b> <code>${orderId}</code>
➥ <b>Sisa Stok:</b> ${product.stock} unit
  `, { parse_mode: 'HTML' });
}

// === PROCESS DEPOSIT FUNCTION ===
async function processDeposit(chatId, userId, userInfo, amount) {
  if (!amount || isNaN(amount) || amount < PAYMENT_SETTINGS.MIN_DEPOSIT) {
    return bot.sendMessage(chatId, `
<blockquote>⚠️ </blockquote>
➥ Deposit: <code>Rp ${amount ? amount.toLocaleString('id-ID') : '0'}</code>
➥ Minimal: <code>Rp ${PAYMENT_SETTINGS.MIN_DEPOSIT.toLocaleString('id-ID')}</code>
    `, { parse_mode: 'HTML' });
  }

  const depositId = `DP-${Date.now().toString().slice(-8)}`;
  const fee = calculateAdminFee(amount);
  const total = calculateTotalAmount(amount);

  productDB.deposits[depositId] = {
    id: depositId,
    user_id: userId,
    amount: amount,
    admin_fee: fee,
    total_amount: total,
    status: 'pending',
    created_at: new Date().toISOString(),
    proof: null
  };
  saveProductData(); // SIMPAN KE PRODUCT_FILE

  if (depositSessions[userId]) {
    delete depositSessions[userId].waitingForCustomAmount;
  }

  depositSessions[userId] = { 
    depositId, 
    amount: amount, 
    total: total,
    timer: null 
  };

  const caption = `
<blockquote>💎 </blockquote>

✧ <b>Detail Deposit</b> ✧
➥ <b>ID:</b> <code>${depositId}</code>
➥ <b>Jumlah:</b> <code>Rp ${amount.toLocaleString('id-ID')}</code>
➥ <b>Biaya Admin:</b> <code>Rp ${fee.toLocaleString('id-ID')}</code>
➥ <b>Total Transfer:</b> <code>Rp ${total.toLocaleString('id-ID')}</code>

<blockquote>📤 Kirim bukti transfer ke sini
⏳ Batas waktu 5 menit</blockquote>`;

  const message = await bot.sendPhoto(chatId, PAYMENT_SETTINGS.QRIS_DATA.image_url, {
    caption,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🔄 Cek Status', callback_data: `check_deposit_${depositId}` },
          { text: '❌ Cancelkan', callback_data: `cancel_deposit_${depositId}` }
        ],
        [
          { text: '💳 Cek Saldo', callback_data: 'cek_saldo' },
          { text: '🛍️ Lihat Produk', callback_data: 'lihat_produk' }
        ]
      ]
    }
  });

  await bot.sendMessage(OWNER_IDS[0], `
<blockquote>📥 </blockquote>
➥ <b>User:</b> <a href="tg://user?id=${userId}">${userInfo.first_name}</a>
➥ <b>Jumlah:</b> <code>Rp ${amount.toLocaleString('id-ID')}</code>
➥ <b>Total:</b> <code>Rp ${total.toLocaleString('id-ID')}</code>
➥ <b>ID:</b> <code>${depositId}</code>
➥ <b>Status:</b> Menunggu Bukti Transfer
  `, { parse_mode: 'HTML' });

  const timeout = setTimeout(async () => {
    const dep = productDB.deposits[depositId];
    if (dep && dep.status === 'pending') {
      dep.status = 'expired';
      saveProductData(); // SIMPAN KE PRODUCT_FILE
      
      if (depositSessions[userId]) {
        delete depositSessions[userId];
      }

      await bot.sendMessage(chatId, `
<blockquote>⏰ </blockquote>
➥ <b>ID:</b> <code>${depositId}</code>
➥ <b>Status:</b> Expired - Silakan ulangi deposit
      `, { parse_mode: 'HTML' });

      try {
        await bot.editMessageReplyMarkup({ inline_keyboard: [] }, {
          chat_id: chatId,
          message_id: message.message_id
        });
      } catch (error) {}
    }
  }, 5 * 60 * 1000);

  depositSessions[userId].timer = timeout;
}

// === CALLBACK QUERY HANDLER ===
bot.on('callback_query', async (query) => {
  const data = query.data;
  const chatId = query.message.chat.id;
  const userId = query.from.id.toString();
  const messageId = query.message.message_id;

  try {
    if (data.startsWith('deposit_')) {
      await bot.answerCallbackQuery(query.id);
      
      if (data === 'deposit_custom') {
        depositSessions[userId] = { waitingForCustomAmount: true };
        
        const text = `
<blockquote>📝 </blockquote>
➥ <b>Kirim nominal deposit:</b>
➥ <b>Contoh:</b> <code>75000</code>

<code>────────────────────</code>
💠 <b>Minimal:</b> Rp ${PAYMENT_SETTINGS.MIN_DEPOSIT.toLocaleString('id-ID')}

⚠️ <b>Note:</b> Hanya kirim angka saja, tanpa titik/koma
        `;

        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '↩️ Kembali', callback_data: 'deposit_menu' }]
            ]
          }
        });
        return;
      }

      const amountStr = data.split('_')[1];
      const amount = parseInt(amountStr);
      
      if (!isNaN(amount) && amount >= PAYMENT_SETTINGS.MIN_DEPOSIT) {
        await processDeposit(chatId, userId, query.from, amount);
      } else {
        const text = `
<blockquote>⚠️ </blockquote>
➥ <b>Nominal:</b> ${amountStr}
➥ <b>Status:</b> Silakan pilih nominal lain
        `;

        await bot.editMessageText(text, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '↩️ Kembali', callback_data: 'deposit_menu' }]
            ]
          }
        });
      }
      return;
    }

    if (data.startsWith('product_')) {
      await bot.answerCallbackQuery(query.id);
      const productId = data.split('_')[1];
      await showProductDetail(chatId, userId, productId, messageId);
      return;
    }

    if (data.startsWith('buy_')) {
      await bot.answerCallbackQuery(query.id);
      const [_, productId, qty] = data.split('_');
      await processBuy(chatId, userId, productId, parseInt(qty), query.from, messageId);
      return;
    }

    if (data === 'cek_saldo') {
      await bot.answerCallbackQuery(query.id);
      const user = initializeUser(userId, query.from);
      const text = `
<blockquote>💳 </blockquote>

👤 <b>User:</b> ${query.from.first_name}
💰 <b>Saldo:</b> <code>Rp ${user.balance.toLocaleString('id-ID')}</code>
📅 <b>Update:</b> ${new Date().toLocaleString('id-ID')}

<code>────────────────────</code>
💎 <i>Saldo dapat digunakan untuk membeli produk</i>
      `;

      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '💳 Deposit', callback_data: 'deposit_menu' },
              { text: '🛍️ Beli Produk', callback_data: 'lihat_produk' }
            ],
            [
              { text: '🔄 Refresh', callback_data: 'refresh_saldo' }
            ]
          ]
        }
      });
      return;
    }

    if (data === 'refresh_saldo') {
      await bot.answerCallbackQuery(query.id, { text: 'Saldo diperbarui!' });
      const user = initializeUser(userId, query.from);
      const text = `
<blockquote>💳 </blockquote>

👤 <b>User:</b> ${query.from.first_name}
💰 <b>Saldo:</b> <code>Rp ${user.balance.toLocaleString('id-ID')}</code>
📅 <b>Update:</b> ${new Date().toLocaleString('id-ID')}

<code>────────────────────</code>
💎 <i>Saldo dapat digunakan untuk membeli produk</i>
      `;

      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '💳 Deposit', callback_data: 'deposit_menu' },
              { text: '🛍️ Beli Produk', callback_data: 'lihat_produk' }
            ],
            [
              { text: '🔄 Refresh', callback_data: 'refresh_saldo' }
            ]
          ]
        }
      });
      return;
    }

    if (data === 'kembali_list' || data === 'lihat_produk') {
      await bot.answerCallbackQuery(query.id);
      await showStockList(chatId, messageId, query.from);
      return;
    }

    if (data === 'deposit_menu') {
      await bot.answerCallbackQuery(query.id);
      
      const text = `
<blockquote>💳 </blockquote>

💰 <b>Pilih Nominal Deposit:</b>
➥ Deposit cepat dengan nominal yang tersedia

<code>────────────────────</code>
💠 <b>Minimal Deposit:</b> Rp ${PAYMENT_SETTINGS.MIN_DEPOSIT.toLocaleString('id-ID')}
      `;

      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '💰 10K', callback_data: 'deposit_10000' },
              { text: '💰 25K', callback_data: 'deposit_25000' },
              { text: '💰 50K', callback_data: 'deposit_50000' }
            ],
            [
              { text: '💰 100K', callback_data: 'deposit_100000' },
              { text: '💰 250K', callback_data: 'deposit_250000' },
              { text: '💰 500K', callback_data: 'deposit_500000' }
            ],
            [
              { text: '📝 Custom Amount', callback_data: 'deposit_custom' }
            ],
            [
              { text: '💳 Cek Saldo', callback_data: 'cek_saldo' },
              { text: '🛍️ Lihat Produk', callback_data: 'lihat_produk' }
            ]
          ]
        }
      });
      return;
    }

    if (data === 'refresh_stock') {
      await bot.answerCallbackQuery(query.id, { text: 'Stok diperbarui!' });
      await showStockList(chatId, messageId, query.from);
      return;
    }

    if (data === 'stok_habis') {
      return await bot.answerCallbackQuery(query.id, {
        text: '❌ Stok produk sudah habis',
        show_alert: true
      });
    }

    if (data.startsWith('check_deposit_')) {
      const depositId = data.split('_')[2];
      const deposit = productDB.deposits[depositId];
      if (!deposit) {
        return await bot.answerCallbackQuery(query.id, {
          text: 'Deposit tidak ditemukan',
          show_alert: true
        });
      }
      return await bot.answerCallbackQuery(query.id, {
        text: `Status: ${deposit.status.toUpperCase()}`,
        show_alert: true
      });
    }

    if (data.startsWith('cancel_deposit_')) {
      const depositId = data.split('_')[2];
      const deposit = productDB.deposits[depositId];
      
      if (!deposit) {
        return await bot.answerCallbackQuery(query.id, {
          text: 'Deposit tidak ditemukan',
          show_alert: true
        });
      }

      if (deposit.status !== 'pending') {
        return await bot.answerCallbackQuery(query.id, {
          text: 'Deposit sudah diproses',
          show_alert: true
        });
      }

      deposit.status = 'cancelled';
      saveProductData(); // SIMPAN KE PRODUCT_FILE

      if (depositSessions[userId] && depositSessions[userId].timer) {
        clearTimeout(depositSessions[userId].timer);
      }
      delete depositSessions[userId];

      await bot.answerCallbackQuery(query.id, { text: 'Deposit dibatalkan' });
      
      const text = `
<blockquote>❌ </blockquote>
➥ <b>ID:</b> <code>${depositId}</code>
➥ <b>Status:</b> Dibatalkan oleh user
      `;

      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '💳 Deposit Lagi', callback_data: 'deposit_menu' },
              { text: '🛍️ Lihat Produk', callback_data: 'lihat_produk' }
            ]
          ]
        }
      });
    }

    if (data.startsWith('approve_deposit_') || data.startsWith('reject_deposit_')) {
      const depositId = data.split('_')[2];
      const deposit = productDB.deposits[depositId];
      
      if (!deposit) {
        return await bot.answerCallbackQuery(query.id, {
          text: 'Deposit tidak ditemukan',
          show_alert: true
        });
      }

      const userId = deposit.user_id;
      const ownerId = query.from.id.toString();

      if (!isAnyOwner(ownerId)) {
        return await bot.answerCallbackQuery(query.id, {
          text: 'Hanya owner yang bisa konfirmasi',
          show_alert: true
        });
      }

      if (data.startsWith('approve')) {
        deposit.status = 'approved';
        const user = initializeUser(userId);
        user.balance += deposit.amount;
        saveProductData(); // SIMPAN KE PRODUCT_FILE

        await bot.answerCallbackQuery(query.id, { text: 'Deposit disetujui!' });
        await bot.editMessageReplyMarkup({ inline_keyboard: [] }, {
          chat_id: chatId,
          message_id: query.message.message_id
        });

        await bot.sendMessage(userId, `
<blockquote>🎉 </blockquote>
➥ <b>ID:</b> <code>${depositId}</code>
➥ <b>Jumlah:</b> <code>Rp ${deposit.amount.toLocaleString('id-ID')}</code>
➥ <b>Status:</b> Saldo berhasil ditambahkan 💎
➥ <b>Saldo Sekarang:</b> <code>Rp ${user.balance.toLocaleString('id-ID')}</code>

<code>────────────────────</code>
🛍️ <i>Silakan gunakan saldo untuk membeli produk</i>
        `, { parse_mode: 'HTML' });

      } else {
        deposit.status = 'rejected';
        saveProductData(); // SIMPAN KE PRODUCT_FILE

        await bot.answerCallbackQuery(query.id, { text: 'Deposit ditolak!' });
        await bot.editMessageReplyMarkup({ inline_keyboard: [] }, {
          chat_id: chatId,
          message_id: query.message.message_id
        });

        await bot.sendMessage(userId, `
<blockquote>❌ </blockquote>
➥ <b>ID:</b> <code>${depositId}</code>
➥ <b>Status:</b> Deposit kamu ditolak oleh admin
➥ <b>Alasan:</b> Bukti transfer tidak valid

<code>────────────────────</code>
💡 <i>Hubungi admin untuk informasi lebih lanjut</i>
        `, { parse_mode: 'HTML' });
      }
    }

  } catch (error) {
    console.error('Callback error:', error);
    await bot.answerCallbackQuery(query.id, {
      text: 'Terjadi error, coba lagi',
      show_alert: true
    });
  }
});

// === HANDLE CUSTOM DEPOSIT AMOUNT ===
bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;
  
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  if (depositSessions[userId] && depositSessions[userId].waitingForCustomAmount) {
    const amount = parseInt(msg.text.replace(/[^\d]/g, ''));
    
    if (!isNaN(amount) && amount >= PAYMENT_SETTINGS.MIN_DEPOSIT) {
      await processDeposit(chatId, userId, msg.from, amount);
    } else {
      await bot.sendMessage(chatId, `
<blockquote>⚠️ </blockquote>
➥ <b>Input:</b> ${msg.text}
➥ <b>Minimal:</b> Rp ${PAYMENT_SETTINGS.MIN_DEPOSIT.toLocaleString('id-ID')}

<code>────────────────────</code>
💡 <b>Contoh input yang benar:</b>
• <code>75000</code> (tanpa titik/koma)
• <code>100000</code> (langsung angka)
      `, { parse_mode: 'HTML' });
    }
    
    delete depositSessions[userId].waitingForCustomAmount;
  }
});

// === HANDLE BUKTI TRANSFER PHOTO ===
bot.on('photo', async (msg) => {
  const userId = msg.from.id.toString();
  
  const userSession = depositSessions[userId];
  if (!userSession || !userSession.depositId) return;

  const depositId = userSession.depositId;
  const deposit = productDB.deposits[depositId];
  
  if (!deposit || deposit.status !== 'pending') return;

  if (userSession.timer) {
    clearTimeout(userSession.timer);
  }

  const fileId = msg.photo[msg.photo.length - 1].file_id;
  deposit.proof = fileId;
  deposit.status = 'review';
  saveProductData(); // SIMPAN KE PRODUCT_FILE

  await bot.sendMessage(msg.chat.id, `
<blockquote>✅ </blockquote>
➥ <b>ID:</b> <code>${depositId}</code>
➥ <b>Status:</b> Menunggu konfirmasi admin...
➥ <b>Estimasi:</b> 1-5 menit
  `, { parse_mode: 'HTML' });

  await bot.sendPhoto(OWNER_IDS[0], fileId, {
    caption: `
<blockquote>📩 </blockquote>
➥ <b>ID:</b> <code>${depositId}</code>
➥ <b>User:</b> <a href="tg://user?id=${userId}">${msg.from.first_name}</a>
➥ <b>Jumlah:</b> <code>Rp ${deposit.amount.toLocaleString('id-ID')}</code>
➥ <b>Total:</b> <code>Rp ${deposit.total_amount.toLocaleString('id-ID')}</code>
➥ <b>Status:</b> Menunggu Konfirmasi
    `,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Approve', callback_data: `approve_deposit_${depositId}` },
          { text: '❌ Reject', callback_data: `reject_deposit_${depositId}` }
        ]
      ]
    }
  });

  delete depositSessions[userId];
});

// === HANDLE ADDPRODUCT WITH DETAILS ===
bot.onText(/^\/addproduct/, async (msg) => {
  if (!(await cekAkses("utama", msg))) return;
  
  const lines = msg.text.split('\n').slice(1);
  const details = {};
  
  for (const line of lines) {
    const [key, ...val] = line.split(':');
    if (key && val.length) {
      details[key.trim().toLowerCase()] = val.join(':').trim();
    }
  }

  if (!details.nama || !details.id) {
    return bot.sendMessage(msg.chat.id, `
<blockquote>⚙️ </blockquote>
➥ <b>Gunakan format:</b>
<code>/addproduct
Nama: Contoh Produk
ID: contoh
Deskripsi: Deskripsi produk (opsional)</code>
    `, { parse_mode: 'HTML' });
  }

  const id = details.id.toLowerCase();
  if (productDB.products[id]) {
    return bot.sendMessage(msg.chat.id, `
<blockquote>⚠️ </blockquote>
➥ <b>ID:</b> <code>${id}</code>
➥ <b>Status:</b> Produk dengan ID ini sudah ada
    `, { parse_mode: 'HTML' });
  }

  productDB.products[id] = {
    id,
    name: details.nama,
    description: details.deskripsi || 'Tidak ada deskripsi',
    price: 0,
    stock: 0,
    fileId: null,
    created_at: new Date().toISOString()
  };
  saveProductData(); // SIMPAN KE PRODUCT_FILE

  await bot.sendMessage(msg.chat.id, `
<blockquote>✅ </blockquote>

🏷️ <b>Nama:</b> ${details.nama}
🆔 <b>ID:</b> <code>${id}</code>
📝 <b>Deskripsi:</b> ${details.deskripsi || 'Tidak ada deskripsi'}

<code>────────────────────</code>
📦 <b>Status:</b> Gunakan <code>/addstock</code> untuk menambah harga & stok
  `, { parse_mode: 'HTML' });
});

// === HANDLE ADDSTOCK WITH REPLY ===
bot.onText(/^\/addstock(?:\s+(.+))?/, async (msg, match) => {
  if (!(await cekAkses("utama", msg))) return;
  
  const args = match[1] ? match[1].trim().split(/\s+/) : [];
  const productId = args[0]?.toLowerCase();
  const price = parseInt(args[1]);
  const stock = parseInt(args[2]);
  const reply = msg.reply_to_message;

  if (!reply || !reply.document) {
    return bot.sendMessage(msg.chat.id, `
<blockquote>📁 </blockquote>
➥ <b>Status:</b> Reply ke file produk terlebih dahulu!
➥ <b>Format:</b> <code>/addstock [id] [harga] [stok]</code>
    `, { parse_mode: 'HTML' });
  }

  if (!productId || isNaN(price) || isNaN(stock)) {
    return bot.sendMessage(msg.chat.id, `
<blockquote>⚠️ </blockquote>
➥ <b>Format:</b> <code>/addstock [id] [harga] [stok]</code>
➥ <b>Contoh:</b> <code>/addstock vip1 50000 10</code>
    `, { parse_mode: 'HTML' });
  }

  const product = productDB.products[productId];
  if (!product) {
    return bot.sendMessage(msg.chat.id, `
<blockquote>❌ </blockquote>
➥ <b>ID:</b> <code>${productId}</code>
➥ <b>Status:</b> Buat produk dulu dengan /addproduct
    `, { parse_mode: 'HTML' });
  }

  const file = reply.document;
  product.price = price;
  product.stock += stock;
  product.fileId = file.file_id;
  saveProductData(); // SIMPAN KE PRODUCT_FILE

  await bot.sendMessage(msg.chat.id, `
<blockquote>✅ </blockquote>

🏷️ <b>Produk:</b> ${product.name}
🆔 <b>ID:</b> <code>${productId}</code>
💰 <b>Harga:</b> <code>Rp ${price.toLocaleString('id-ID')}</code>
📦 <b>Stok Ditambah:</b> +${stock} unit
📊 <b>Stok Sekarang:</b> ${product.stock} unit

<code>────────────────────</code>
🎯 <b>Status:</b> Produk sudah ready untuk dijual!
  `, { parse_mode: 'HTML' });
});

// === /setmaintenance ===
bot.onText(/^\/setmaintenance(?:\s+(on|off))?$/, async (msg, match) => {
  if (!(await cekAkses("utama", msg))) return;

  const senderId = msg.from.id.toString();
  const chatId = msg.chat.id;

  const arg = match[1];
  if (!arg) {
    const status = isMaintenance() ? "🔴 ON (Aktif)" : "🟢 OFF (Nonaktif)";
    return bot.sendMessage(chatId, `
<blockquote>⚙️ </blockquote>
➥ <b>Status Saat Ini:</b> ${status}`, { parse_mode: "HTML" });
  }

  if (arg.toLowerCase() === "on") {
    setMaintenance(true);
    return bot.sendMessage(chatId, `
<blockquote>🔴 </blockquote>
➥ <b>Status:</b> Mode maintenance telah AKTIF
➥ <b>Keterangan:</b> Semua user akan menerima notifikasi dan tidak bisa menggunakan bot`, { parse_mode: "HTML" });
  } else if (arg.toLowerCase() === "off") {
    setMaintenance(false);
    return bot.sendMessage(chatId, `
<blockquote> </blockquote>
➥ <b>Status:</b> Mode maintenance telah DINONAKTIFKAN
➥ <b>Keterangan:</b> Bot kembali normal digunakan`, { parse_mode: "HTML" });
  } else {
    return bot.sendMessage(chatId, `
<blockquote>⚠️ </blockquote>
➥ <b>Gunakan:</b> <code>/setmaintenance on</code> atau <code>/setmaintenance off</code>`, { parse_mode: "HTML" });
  }
});

// === /cekid ===
const { createCanvas, loadImage, registerFont } = require('canvas');
// Helper function untuk mendapatkan language name
function getLanguageName(code) {
    const languages = {
        'en': 'English',
        'id': 'Indonesian',
        'es': 'Spanish',
        'fr': 'French',
        'de': 'German',
        'ru': 'Russian',
        'ar': 'Arabic',
        'zh': 'Chinese',
        'ja': 'Japanese',
        'ko': 'Korean',
        'pt': 'Portuguese',
        'it': 'Italian',
        'tr': 'Turkish',
        'hi': 'Hindi',
        'th': 'Thai',
        'vi': 'Vietnamese'
    };
    return languages[code] || code.toUpperCase();
}

// Fungsi untuk menggambar pattern heksagon
function drawHexagonPattern(ctx, width, height) {
    ctx.save();
    ctx.strokeStyle = 'rgba(0, 255, 136, 0.1)';
    ctx.lineWidth = 1;
    
    const hexSize = 40;
    for (let x = 0; x < width; x += hexSize * 1.5) {
        for (let y = 0; y < height; y += hexSize * Math.sqrt(3)) {
            drawHexagon(ctx, x + (y % (hexSize * Math.sqrt(3) * 2) > hexSize * Math.sqrt(3) ? hexSize * 0.75 : 0), y, hexSize);
        }
    }
    ctx.restore();
}

function drawHexagon(ctx, x, y, size) {
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
        const angle = (i * Math.PI) / 3;
        const px = x + size * Math.cos(angle);
        const py = y + size * Math.sin(angle);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.stroke();
}

// Fungsi untuk rounded rectangle
function roundRect(ctx, x, y, width, height, radius) {
    if (width < 2 * radius) radius = width / 2;
    if (height < 2 * radius) radius = height / 2;
    
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + width, y, x + width, y + height, radius);
    ctx.arcTo(x + width, y + height, x, y + height, radius);
    ctx.arcTo(x, y + height, x, y, radius);
    ctx.arcTo(x, y, x + width, y, radius);
    ctx.closePath();
}

// Fungsi untuk placeholder foto profil
function drawProfilePlaceholder(ctx, x, y, radius, photoCount = 0) {
    ctx.save();
    
    // Background gradient
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, '#333333');
    gradient.addColorStop(1, '#1a1a1a');
    
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
    
    // Icon
    ctx.fillStyle = '#666666';
    ctx.font = 'bold 40px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('👤', x, y);
    
    // Border
    ctx.strokeStyle = '#666666';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.stroke();
    
    // Badge dengan jumlah foto
    if (photoCount > 0) {
        ctx.fillStyle = '#00ff88';
        ctx.beginPath();
        ctx.arc(x + radius * 0.7, y + radius * 0.7, 15, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px Arial';
        ctx.fillText(photoCount > 9 ? '9+' : photoCount.toString(), x + radius * 0.7, y + radius * 0.7);
    }
    
    ctx.restore();
}

// Fungsi untuk info box
function drawInfoBox(ctx, x, y, icon, label, value) {
    ctx.save();
    
    // Box background
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    roundRect(ctx, x, y, 230, 90, 15);
    ctx.fill();
    
    // Border
    ctx.strokeStyle = 'rgba(0, 255, 136, 0.3)';
    ctx.lineWidth = 1;
    roundRect(ctx, x, y, 230, 90, 15);
    ctx.stroke();
    
    // Icon
    ctx.fillStyle = '#00ff88';
    ctx.font = '24px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(icon, x + 20, y + 30);
    
    // Label
    ctx.fillStyle = '#88ffcc';
    ctx.font = '12px "Montserrat", Arial, sans-serif';
    ctx.fillText(label, x + 55, y + 25);
    
    // Value
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 16px "Montserrat", Arial, sans-serif';
    
    // Truncate long values
    let displayValue = value;
    if (value.length > 20) {
        displayValue = value.substring(0, 17) + '...';
    }
    
    ctx.fillText(displayValue, x + 55, y + 55);
    
    ctx.restore();
}

// Fungsi untuk status indicator
function drawStatusIndicator(ctx, x, y, label, value, color) {
    ctx.save();
    
    // Label
    ctx.fillStyle = '#cccccc';
    ctx.font = '14px "Montserrat", Arial, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(label, x, y);
    
    // Value
    ctx.fillStyle = color;
    ctx.font = 'bold 16px "Montserrat", Arial, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(value, x + 200, y);
    
    ctx.restore();
}

// Fungsi untuk DC info
function getDCInfo(dcId) {
    const dcInfo = {
        1: 'Miami, USA',
        2: 'Amsterdam, NL',
        3: 'Miami, USA',
        4: 'Amsterdam, NL',
        5: 'Singapore, SG'
    };
    return dcInfo[dcId] || 'Unknown';
}

// Fungsi untuk membuat ID Card
async function generateIDCard(userData, botToken, DEVELOPER) {
    const {
        userId,
        firstName,
        lastName,
        username,
        languageCode,
        hasPhoto,
        photoCount,
        profilePhotoBuffer,
        msg,
        data,
        isPremiumUser,
        dcId,
        joinDate,
        date,
        time
    } = userData;

    const fullName = lastName ? `${firstName} ${lastName}` : firstName;
    
    try {
        const canvas = createCanvas(600, 800);
        const ctx = canvas.getContext('2d');
        
        // Background gradient yang lebih menarik
        const gradient = ctx.createLinearGradient(0, 0, 600, 800);
        gradient.addColorStop(0, '#0a192f');
        gradient.addColorStop(0.5, '#112240');
        gradient.addColorStop(1, '#0a192f');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 600, 800);

        // Pattern heksagon
        drawHexagonPattern(ctx, 600, 800);
        
        // Main card container dengan efek glassmorphism
        ctx.save();
        ctx.beginPath();
        roundRect(ctx, 30, 30, 540, 740, 25);
        ctx.clip();
        
        // Glass effect background
        ctx.fillStyle = 'rgba(255, 255, 255, 0.07)';
        ctx.fillRect(30, 30, 540, 740);
        
        // Border glow effect
        ctx.strokeStyle = '#00ff88';
        ctx.lineWidth = 3;
        ctx.shadowColor = '#00ff88';
        ctx.shadowBlur = 15;
        roundRect(ctx, 30, 30, 540, 740, 25);
        ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.restore();

        // Header section dengan efek gradien
        const textGradient = ctx.createLinearGradient(150, 60, 450, 90);
        textGradient.addColorStop(0, '#00ff88');
        textGradient.addColorStop(1, '#00ccff');
        
        ctx.fillStyle = textGradient;
        ctx.font = 'bold 32px "Montserrat", Arial, sans-serif';
        ctx.textAlign = 'center';
        ctx.shadowColor = 'rgba(0, 255, 136, 0.5)';
        ctx.shadowBlur = 10;
        ctx.fillText('TELEGRAM ID CARD', 300, 80);
        ctx.shadowBlur = 0;
        
        // Subtitle
        ctx.fillStyle = '#88ffcc';
        ctx.font = '14px "Montserrat", Arial, sans-serif';
        ctx.fillText('Digital Identity Verification', 300, 110);

        // Separator line dengan efek gradien
        const lineGradient = ctx.createLinearGradient(50, 0, 550, 0);
        lineGradient.addColorStop(0, 'transparent');
        lineGradient.addColorStop(0.5, '#00ff88');
        lineGradient.addColorStop(1, 'transparent');
        
        ctx.strokeStyle = lineGradient;
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        ctx.beginPath();
        ctx.moveTo(50, 130);
        ctx.lineTo(550, 130);
        ctx.stroke();
        ctx.setLineDash([]);

        // Profile photo section
        const photoX = 300;
        const photoY = 230;
        const photoRadius = 80;
        
        if (hasPhoto && profilePhotoBuffer) {
            try {
                const profileImage = await loadImage(profilePhotoBuffer);
                
                ctx.save();
                ctx.beginPath();
                ctx.arc(photoX, photoY, photoRadius, 0, Math.PI * 2, true);
                ctx.closePath();
                ctx.clip();
                
                ctx.drawImage(profileImage, photoX - photoRadius, photoY - photoRadius, photoRadius * 2, photoRadius * 2);
                ctx.restore();
                
                // Photo border dengan efek glow
                ctx.strokeStyle = '#00ff88';
                ctx.lineWidth = 4;
                ctx.shadowColor = '#00ff88';
                ctx.shadowBlur = 15;
                ctx.beginPath();
                ctx.arc(photoX, photoY, photoRadius, 0, Math.PI * 2);
                ctx.stroke();
                ctx.shadowBlur = 0;
                
                // Photo status badge
                ctx.fillStyle = '#00ff88';
                ctx.beginPath();
                ctx.arc(photoX + photoRadius * 0.7, photoY + photoRadius * 0.7, 18, 0, Math.PI * 2);
                ctx.fill();
                ctx.fillStyle = '#000';
                ctx.font = 'bold 16px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('✓', photoX + photoRadius * 0.7, photoY + photoRadius * 0.7);
                
            } catch (err) {
                console.error("Error loading profile image:", err);
                drawProfilePlaceholder(ctx, photoX, photoY, photoRadius, photoCount);
            }
        } else {
            drawProfilePlaceholder(ctx, photoX, photoY, photoRadius, photoCount);
        }

        // User information section
        const nameGradient = ctx.createLinearGradient(200, 340, 400, 360);
        nameGradient.addColorStop(0, '#ffffff');
        nameGradient.addColorStop(1, '#00ff88');
        
        ctx.fillStyle = nameGradient;
        ctx.font = 'bold 22px "Montserrat", Arial, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(fullName, 300, 350);
        
        ctx.fillStyle = '#88ffcc';
        ctx.font = '16px "Montserrat", Arial, sans-serif';
        ctx.fillText(username, 300, 380);

        // Info boxes dengan layout yang lebih baik
        const infoData = [
            { label: 'USER ID', value: userId.toString(), icon: '🔐' },
            { label: 'DATACENTER', value: `DC ${dcId}`, icon: '🏢' },
            { label: 'LANGUAGE', value: getLanguageName(languageCode), icon: '🌐' },
            { label: 'JOIN DATE', value: joinDate, icon: '📅' }
        ];

        let yPos = 420;
        infoData.forEach((info, index) => {
            drawInfoBox(ctx, 50 + (index % 2) * 250, yPos, info.icon, info.label, info.value);
            if (index % 2 === 1) yPos += 100;
        });

        // Status indicators dengan layout grid
        yPos += 50;
        const statuses = [
            { 
                label: 'Profile Photo', 
                value: hasPhoto ? `✅ (${photoCount})` : '❌', 
                color: hasPhoto ? '#00ff88' : '#ff4444' 
            },
            { 
                label: 'Telegram Premium', 
                value: msg.from.is_premium ? '✅' : '❌', 
                color: msg.from.is_premium ? '#00ff88' : '#ff4444' 
            },
            { 
                label: 'Verified', 
                value: msg.from.is_verified ? '✅' : '❌', 
                color: msg.from.is_verified ? '#00ff88' : '#ff4444' 
            },
            { 
                label: 'Bot Premium', 
                value: isPremiumUser ? '✅' : '❌', 
                color: isPremiumUser ? '#00ff88' : '#ff4444' 
            }
        ];

        statuses.forEach((status, index) => {
            drawStatusIndicator(ctx, 50 + (index % 2) * 250, yPos, status.label, status.value, status.color);
            if (index % 2 === 1) yPos += 40;
        });

        // Additional stats
        const additionalStats = [
            { 
                label: 'Scam Account', 
                value: msg.from.is_scam ? '✅' : '❌', 
                color: msg.from.is_scam ? '#ff4444' : '#00ff88' 
            },
            { 
                label: 'Fake Account', 
                value: msg.from.is_fake ? '✅' : '❌', 
                color: msg.from.is_fake ? '#ff4444' : '#00ff88' 
            },
            { 
                label: 'Blacklisted', 
                value: data.blacklist && data.blacklist.includes(userId.toString()) ? '✅' : '❌', 
                color: data.blacklist && data.blacklist.includes(userId.toString()) ? '#ff4444' : '#00ff88' 
            },
            { 
                label: 'Registered', 
                value: data.users && data.users.includes(userId.toString()) ? '✅' : '❌', 
                color: data.users && data.users.includes(userId.toString()) ? '#00ff88' : '#ff4444' 
            }
        ];

        additionalStats.forEach((stat, index) => {
            drawStatusIndicator(ctx, 50 + (index % 2) * 250, yPos, stat.label, stat.value, stat.color);
            if (index % 2 === 1) yPos += 40;
        });

        // Footer section
        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.font = '12px "Montserrat", Arial, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`Generated on ${date} at ${time}`, 300, 720);
        
        const poweredGradient = ctx.createLinearGradient(200, 730, 400, 750);
        poweredGradient.addColorStop(0, '#00ff88');
        poweredGradient.addColorStop(1, '#00ccff');
        
        ctx.fillStyle = poweredGradient;
        ctx.font = 'bold 14px "Montserrat", Arial, sans-serif';
        ctx.fillText(`Powered by ${DEVELOPER}`, 300, 745);

        // QR Code style element
        drawQRCodePlaceholder(ctx, 500, 680, 40);

        // Scan line animation effect
        ctx.save();
        const scanGradient = ctx.createLinearGradient(0, 0, 0, 20);
        scanGradient.addColorStop(0, 'rgba(0, 255, 136, 0)');
        scanGradient.addColorStop(0.5, 'rgba(0, 255, 136, 0.3)');
        scanGradient.addColorStop(1, 'rgba(0, 255, 136, 0)');
        
        ctx.fillStyle = scanGradient;
        ctx.globalCompositeOperation = 'lighter';
        roundRect(ctx, 40, 140, 520, 20, 10);
        ctx.fill();
        ctx.restore();

        return canvas.toBuffer('image/png');
        
    } catch (err) {
        console.error("Error generating ID card:", err);
        throw err;
    }
}

function drawQRCodePlaceholder(ctx, x, y, size) {
    ctx.save();
    
    // QR background dengan efek glass
    ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
    roundRect(ctx, x - size/2, y - size/2, size, size, 10);
    ctx.fill();
    
    // Border dengan glow
    ctx.strokeStyle = '#00ff88';
    ctx.lineWidth = 2;
    ctx.shadowColor = '#00ff88';
    ctx.shadowBlur = 10;
    roundRect(ctx, x - size/2, y - size/2, size, size, 10);
    ctx.stroke();
    ctx.shadowBlur = 0;
    
    // Pattern dasar QR
    ctx.fillStyle = '#ffffff';
    
    // Corner squares
    roundRect(ctx, x - size/2 + 5, y - size/2 + 5, 10, 10, 2);
    roundRect(ctx, x + size/2 - 15, y - size/2 + 5, 10, 10, 2);
    roundRect(ctx, x - size/2 + 5, y + size/2 - 15, 10, 10, 2);
    ctx.fill();
    
    // Center logo Telegram
    ctx.fillStyle = '#00ff88';
    ctx.beginPath();
    ctx.arc(x, y, 8, 0, Math.PI * 2);
    ctx.fill();
    
    // Telegram logo detail
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('T', x, y);
    
    ctx.restore();
}

// Handler command /cekid
bot.onText(/^\/cekid$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const firstName = msg.from.first_name || 'No Name';
    const lastName = msg.from.last_name || '';
    const username = msg.from.username ? '@' + msg.from.username : 'No Username';
    const languageCode = msg.from.language_code || 'Not detected';
    
    // Processing message
    const processingMsg = await bot.sendMessage(chatId, "🔄 <i>Generating your ID Card...</i>", {
        parse_mode: 'HTML'
    });
    
    try {
        const now = new Date();
        const date = now.toLocaleDateString("id-ID", { 
            timeZone: "Asia/Jakarta",
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        const time = now.toLocaleTimeString("id-ID", {
            timeZone: "Asia/Jakarta",
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        
        const dcId = (userId >> 22) % 4;
        const joinDate = new Date((userId >> 32) * 1000 + 1288834974657).toLocaleDateString("id-ID", {
            timeZone: "Asia/Jakarta",
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        const data = loadData();
        const isPremiumUser = data.premium && data.premium[userId.toString()] && Math.floor(Date.now() / 1000) < data.premium[userId.toString()];
        const premiumStatus = isPremiumUser ? "✅ Active" : "❌ Inactive";

        let hasPhoto = false;
        let photoCount = 0;
        let profilePhotoBuffer = null;
        
        try {
            const userProfilePhotos = await bot.getUserProfilePhotos(userId, { limit: 1 });
            hasPhoto = userProfilePhotos.total_count > 0;
            photoCount = userProfilePhotos.total_count;
            
            if (hasPhoto) {
                const fileId = userProfilePhotos.photos[0][0].file_id;
                const file = await bot.getFile(fileId);
                const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
                
                // Gunakan metode fetch yang sesuai dengan environment Anda
                const response = await fetch(fileUrl);
                if (response.ok) {
                    const arrayBuffer = await response.arrayBuffer();
                    profilePhotoBuffer = Buffer.from(arrayBuffer);
                }
            }
        } catch (err) {
            console.error("Error getting profile photos:", err.message);
        }

        // Siapkan data untuk ID Card
        const userData = {
            userId,
            firstName,
            lastName,
            username,
            languageCode,
            hasPhoto,
            photoCount,
            profilePhotoBuffer,
            msg,
            data,
            isPremiumUser,
            dcId,
            joinDate,
            date,
            time
        };

        // Generate ID Card
        const imageBuffer = await generateIDCard(userData, bot.token, DEVELOPER);

        // Hapus processing message
        try {
            await bot.deleteMessage(chatId, processingMsg.message_id);
        } catch (err) {
            console.error("Error deleting processing message:", err);
        }

        // Buat caption HTML
        const caption = `
🎫 <b>TELEGRAM ID CARD</b>

<b>━━━━━━━━━━━━━━━</b>
👤 <b>USER INFORMATION</b>
<b>━━━━━━━━━━━━━━━</b>
├ <b>User ID:</b> <code>${userId}</code>
├ <b>Name:</b> <a href="tg://user?id=${userId}">${firstName} ${lastName}</a>
├ <b>Username:</b> ${username}
├ <b>DC ID:</b> ${dcId} (${getDCInfo(dcId)})
├ <b>Language:</b> ${getLanguageName(languageCode)}
└ <b>Join Date:</b> ${joinDate}

<b>━━━━━━━━━━━━━━━</b>
📊 <b>PROFILE STATUS</b>
<b>━━━━━━━━━━━━━━━</b>
├ <b>Profile Photo:</b> ${hasPhoto ? `✅ Yes (${photoCount} photos)` : '❌ No'}
├ <b>Telegram Premium:</b> ${msg.from.is_premium ? '✅ Yes' : '❌ No'}
├ <b>Verified Account:</b> ${msg.from.is_verified ? '✅ Yes' : '❌ No'}
├ <b>Scam Account:</b> ${msg.from.is_scam ? '✅ Yes' : '❌ No'}
└ <b>Fake Account:</b> ${msg.from.is_fake ? '✅ Yes' : '❌ No'}

<b>━━━━━━━━━━━━━━━</b>
🤖 <b>BOT STATUS</b>
<b>━━━━━━━━━━━━━━━</b>
├ <b>Premium Access:</b> ${premiumStatus}
├ <b>Blacklisted:</b> ${data.blacklist && data.blacklist.includes(userId.toString()) ? '✅ Yes' : '❌ No'}
├ <b>Groups Added:</b> ${data.user_group_count && data.user_group_count[userId.toString()] ? data.user_group_count[userId.toString()] : 0}
└ <b>Registered User:</b> ${data.users && data.users.includes(userId.toString()) ? '✅ Yes' : '❌ No'}

<b>━━━━━━━━━━━━━━━</b>
📅 <b>CHECK INFORMATION</b>
<b>━━━━━━━━━━━━━━━</b>
├ <b>Check Date:</b> ${date}
├ <b>Check Time:</b> ${time}
└ <b>Chat Type:</b> ${msg.chat.type.charAt(0).toUpperCase() + msg.chat.type.slice(1)}

<b>━━━━━━━━━━━━━━━</b>
<i>Generated by ${DEVELOPER} • ${time}</i>`;

        // Kirim ID Card
        await bot.sendPhoto(chatId, imageBuffer, {
            caption: caption,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { 
                            text: "👤 View Profile", 
                            url: `tg://user?id=${userId}` 
                        },
                        { 
                            text: "📊 Full Stats", 
                            callback_data: `stats_${userId}` 
                        }
                    ],
                    [
                        { 
                            text: "🔄 Refresh ID Card", 
                            callback_data: `refresh_cekid_${userId}` 
                        },
                        { 
                            text: "⭐ Save Image", 
                            callback_data: `save_idcard_${userId}` 
                        }
                    ],
                    [
                        {
                            text: "🤖 Check Another User",
                            callback_data: `check_another_user`
                        }
                    ]
                ]
            }
        });

    } catch (err) {
        console.error("❌ Error in /cekid:", err);
        
        // Hapus processing message
        try {
            await bot.deleteMessage(chatId, processingMsg.message_id);
        } catch (e) {}
        
        // Fallback ke versi text-only
        const fallbackCaption = `
🎫 <b>TELEGRAM ID CARD</b>

<b>━━━━━━━━━━━━━━━</b>
👤 <b>USER INFORMATION</b>
<b>━━━━━━━━━━━━━━━</b>
├ <b>User ID:</b> <code>${userId}</code>
├ <b>Name:</b> <a href="tg://user?id=${userId}">${firstName} ${lastName}</a>
├ <b>Username:</b> ${username}
├ <b>DC ID:</b> ${(userId >> 22) % 4}
├ <b>Language:</b> ${getLanguageName(languageCode)}
└ <b>Join Date:</b> ${new Date((userId >> 32) * 1000 + 1288834974657).toLocaleDateString("id-ID", {
    timeZone: "Asia/Jakarta",
    year: 'numeric',
    month: 'long',
    day: 'numeric'
})}

<b>━━━━━━━━━━━━━━━</b>
⚠️ <b>IMAGE GENERATION FAILED</b>
<b>━━━━━━━━━━━━━━━</b>
└ <b>Error:</b> ${err.message}

<i>Try again later or contact support</i>`;
        
        await bot.sendMessage(chatId, fallbackCaption, { 
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { 
                            text: `👤 ${firstName}`, 
                            url: `tg://user?id=${userId}` 
                        }
                    ],
                    [
                        {
                            text: "🔄 Try Again",
                            callback_data: `refresh_cekid_${userId}`
                        }
                    ]
                ]
            }
        });
    }
});

// Update callback handler
bot.on("callback_query", async (query) => {
    if (query.data.startsWith("refresh_cekid_")) {
        const userId = query.data.split("_")[2];
        
        if (query.from.id.toString() !== userId) {
            return await bot.answerCallbackQuery(query.id, {
                text: "❌ This button is not for you!",
                show_alert: true
            });
        }
        
        await bot.answerCallbackQuery(query.id, {
            text: "🔄 Refreshing ID Card...",
            show_alert: false
        });

        try {
            await bot.deleteMessage(query.message.chat.id, query.message.message_id);
        } catch (error) {
            console.error("Error deleting message:", error);
        }
        
        const simulatedMsg = {
            chat: { 
                id: query.message.chat.id,
                type: query.message.chat.type
            },
            from: query.from,
            text: "/cekid"
        };
        
        bot.emit("text", simulatedMsg);
    } else if (query.data.startsWith("stats_")) {
        await bot.answerCallbackQuery(query.id, {
            text: "📊 Statistics feature coming soon!",
            show_alert: false
        });
    } else if (query.data.startsWith("save_idcard_")) {
        await bot.answerCallbackQuery(query.id, {
            text: "✅ ID Card has been saved to your chat!",
            show_alert: true
        });
        
        // Kirim gambar langsung ke user
        try {
            const userId = query.data.split("_")[2];
            const chatId = query.message.chat.id;
            
            // Forward gambar yang ada
            await bot.forwardMessage(query.from.id, chatId, query.message.message_id);
        } catch (err) {
            console.error("Error forwarding image:", err);
        }
    }
});

// === /tourl ===
bot.onText(/^\/tourl$/i, async (msg) => {
  if (!(await requireNotBlacklisted(msg))) return;
  if (!(await requireNotMaintenance(msg))) return;

  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const username = msg.from.first_name || "User";

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, `
<blockquote>❌ </blockquote>

🌸 <b>Cara menggunakan:</b>
➥ <b>1.</b> Reply sebuah file, foto, atau video
➥ <b>2.</b> Ketik <code>/tourl</code>

📝 <b>Contoh:</b>
• Reply foto → /tourl
• Reply video → /tourl  
• Reply file → /tourl

👋 Hai <b>${username}</b> 🌸
`, { parse_mode: "HTML", reply_to_message_id: msg.message_id });
  }

  const repliedMsg = msg.reply_to_message;
  let fileId, fileName, fileType;

  if (repliedMsg.document) {
    fileId = repliedMsg.document.file_id;
    fileName = repliedMsg.document.file_name || `file_${Date.now()}`;
    fileType = "document";
  } else if (repliedMsg.photo) {
    fileId = repliedMsg.photo[repliedMsg.photo.length - 1].file_id;
    fileName = `photo_${Date.now()}.jpg`;
    fileType = "photo";
  } else if (repliedMsg.video) {
    fileId = repliedMsg.video.file_id;
    fileName = `video_${Date.now()}.mp4`;
    fileType = "video";
  } else {
    return bot.sendMessage(chatId, `
<blockquote>❌ 𝗧𝗶𝗱𝗮𝗸 𝗗𝗶𝗱𝘂𝗸𝘂𝗻𝗴</blockquote>
➥ <b>Status:</b> Hanya support file, foto, dan video
➥ <b>Format yang didukung:</b> Document, Photo, Video`, { parse_mode: "HTML", reply_to_message_id: msg.message_id });
  }

  try {
    const processingMsg = await bot.sendMessage(
      chatId,
      `<blockquote>⏳ </blockquote>

📁 <b>Informasi File</b>
➥ <b>Jenis:</b> ${fileType}
➥ <b>Nama:</b> <code>${fileName}</code>
➥ <b>Status:</b> Mohon tunggu sebentar...`,
      { 
        reply_to_message_id: msg.message_id, 
        parse_mode: "HTML" 
      }
    );

    const fileLink = await bot.getFileLink(fileId);
    const response = await axios.get(fileLink, { 
      responseType: "stream",
      timeout: 30000 
    });

    const FormData = require("form-data");
    const form = new FormData();
    form.append("reqtype", "fileupload");
    form.append("fileToUpload", response.data, {
      filename: fileName,
      contentType: response.headers["content-type"] || "application/octet-stream"
    });

    const { data: catboxUrl } = await axios.post("https://catbox.moe/user/api.php", form, {
      headers: form.getHeaders(),
      timeout: 30000
    });

    await bot.editMessageText(
      `<blockquote>✅ </blockquote>

🔗 <b>Informasi URL</b>
➥ <b>URL:</b> <code>${catboxUrl}</code>
➥ <b>Link:</b> ${catboxUrl}

📝 <b>Keterangan</b>
➥ <b>Expired:</b> 24 jam
➥ <b>Status:</b> File berhasil diupload`,
      {
        chat_id: chatId,
        message_id: processingMsg.message_id,
        parse_mode: "HTML"
      }
    );

  } catch (error) {
    console.error("❌ Error di /tourl:", error);
    
    let errorMessage = "❌ Gagal mengupload file ke Catbox. Coba lagi nanti.";
    if (error.code === 'ECONNABORTED') {
      errorMessage = "❌ Timeout: Upload terlalu lama. Coba dengan file yang lebih kecil.";
    } else if (error.response) {
      errorMessage = "❌ Server Catbox sedang error. Coba lagi nanti.";
    }

    bot.sendMessage(chatId, `
<blockquote>❌ 𝗨𝗽𝗹𝗼𝗮𝗱 𝗚𝗮𝗴𝗮𝗹</blockquote>
➥ <b>Error:</b> ${errorMessage}
➥ <b>Status:</b> Silakan coba lagi nanti`, { 
  parse_mode: "HTML",
  reply_to_message_id: msg.message_id 
});
  }
});

// === /done ===
bot.onText(/^\/done(?:\s+(.+))?$/i, async (msg, match) => {
  if (!(await cekAkses("premium", msg))) return;

  const chatId = msg.chat.id;
  const input = match[1]?.trim();
  const replyMsg = msg.reply_to_message;

  if (!input) {
    return bot.sendMessage(chatId, `
<blockquote>📌 </blockquote>

🌸 <b>Gunakan format berikut:</b>
<code>/done nama barang,harga,metode bayar</code>

📝 <b>Contoh:</b>
<code>/done jasa install panel,15000,Dana</code>`, { parse_mode: "HTML" });
  }

  const [namaBarang, hargaBarang, metodeBayar] = input.split(",").map(x => x?.trim());
  if (!namaBarang || !hargaBarang) {
    return bot.sendMessage(chatId, `
<blockquote>❗</blockquote>

🌸 <b>Minimal isi:</b>
➥ <b>Nama barang</b> dan <b>harga</b>

📝 <b>Contoh lengkap:</b>
<code>/done jasa install panel,15000,Dana</code>`, { parse_mode: "HTML" });
  }

  const hargaFormatted = `Rp ${Number(hargaBarang).toLocaleString("id-ID")}`;
  const metodePembayaran = metodeBayar || "Tidak disebutkan";
  const now = new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });

  const caption = `
<blockquote>✅ </blockquote>

🌸 <b>Detail Transaksi</b>
➥ <b>Barang:</b> ${namaBarang}
➥ <b>Nominal:</b> ${hargaFormatted}
➥ <b>Payment:</b> ${metodePembayaran}
➥ <b>Waktu:</b> ${now}

📝 <b>Keterangan:</b> ALL TRX NO REFF!!!

👤 <b>Contact:</b> ${DEVELOPER}
`;

  if (replyMsg && replyMsg.photo) {
    const photos = replyMsg.photo;
    const photoId = photos[photos.length - 1].file_id; 
    await bot.sendPhoto(chatId, photoId, {
      caption: caption,
      parse_mode: "HTML"
    }).catch((err) => {
      console.error("Send photo error:", err);
      bot.sendMessage(chatId, `
<blockquote>⚠️ </blockquote>
➥ <b>Status:</b> Gagal mengirim foto transaksi`, { parse_mode: "HTML" });
    });
  } 
  else {
    await bot.sendMessage(chatId, caption, { parse_mode: "HTML" });
  }
});

// === /backup ===
bot.onText(/^\/backup$/i, async (msg) => {
  if (!(await cekAkses("owner", msg))) return;

  const senderId = msg.from.id.toString();
  const chatId = msg.chat.id;
  const username = msg.from.first_name || "User";

  try {
    const loadingFrames = [
      "⏳ Membuat backup data .",
      "⏳ Membuat backup data ..",
      "⏳ Membuat backup data ...",
      "💽 Sedang mengemas file ...",
      "💿 Menyimpan hasil backup ...",
    ];

    const processing = await bot.sendMessage(chatId, 
`<blockquote>💾 </blockquote>

👤 <b>Informasi</b>
➥ <b>Oleh:</b> ${username}
➥ <b>Waktu:</b> ${new Date().toLocaleString("id-ID")}
➥ <b>Status:</b> Sedang memproses...`,
{ parse_mode: "HTML" });

    let frame = 0;
    const anim = setInterval(() => {
      const frameText = loadingFrames[frame % loadingFrames.length];
      bot.editMessageText(
`<blockquote>💾 </blockquote>

${frameText}

👤 <b>Informasi</b>
➥ <b>Oleh:</b> ${username}
➥ <b>Waktu:</b> ${new Date().toLocaleString("id-ID")}`,
        {
          chat_id: chatId,
          message_id: processing.message_id,
          parse_mode: "HTML"
        }
      ).catch(() => {});
      frame++;
    }, 700);

    await new Promise((r) => setTimeout(r, 2500));
    
    const backupPath = backupData();
    clearInterval(anim);

    if (!backupPath) {
      return bot.editMessageText(
`<blockquote>❌ </blockquote>

🌸 <b>Informasi Error</b>
➥ <b>Status:</b> Tidak ada file data untuk di-backup
➥ <b>Lokasi:</b> <code>${DATA_FILE}</code>
➥ <b>Solusi:</b> Pastikan file database ada`,
        {
          chat_id: chatId,
          message_id: processing.message_id,
          parse_mode: "HTML"
        }
      );
    }

    const stats = fs.statSync(backupPath);
    const sizeKB = (stats.size / 1024).toFixed(2);
    const backupTime = new Date().toLocaleString("id-ID");

    const caption = `
<blockquote>💾 </blockquote>

📁 <b>Detail File</b>
➥ <b>Nama File:</b> <code>${path.basename(backupPath)}</code>  
➥ <b>Ukuran:</b> ${sizeKB} KB  
➥ <b>Lokasi:</b> <code>./backup/</code>

👤 <b>Informasi</b>
➥ <b>Oleh:</b> ${username}  
➥ <b>Waktu:</b> ${backupTime}

<blockquote>✨ Backup berhasil disimpan!  
Gunakan file ini untuk restore bila dibutuhkan 💾</blockquote>
`;

    await bot.editMessageText(
`<blockquote>✅ </blockquote>
➥ <b>Status:</b> Mengirim file backup...`,
      {
        chat_id: chatId,
        message_id: processing.message_id,
        parse_mode: "HTML"
      }
    );

    await bot.sendDocument(chatId, backupPath, { 
      caption: caption, 
      parse_mode: "HTML" 
    });

    const mainOwner = OWNER_IDS[0];
    if (mainOwner && String(mainOwner) !== String(senderId)) {
      await bot.sendMessage(mainOwner, `
<blockquote>📂 </blockquote>

👤 <b>Informasi Backup</b>
➥ <b>Oleh:</b> <a href="tg://user?id=${senderId}">${username}</a>  
➥ <b>Ukuran:</b> ${sizeKB} KB  
➥ <b>Waktu:</b> ${backupTime}  
➥ <b>Lokasi:</b> ./database/backup/`,
{ parse_mode: "HTML" });
    }

  } catch (error) {
    console.error("❌ Error backup manual:", error);
    bot.sendMessage(chatId, `
<blockquote>❌ </blockquote>

🌸 <b>Informasi Error</b>
➥ <b>Error:</b> <code>${error.message}</code>
➥ <b>Status:</b> Terjadi kesalahan saat membuat backup data

🔧 <b>Solusi:</b> Silakan coba lagi nanti atau hubungi Developer`,
{ parse_mode: "HTML" });
  }
});
bot.onText(/\/play (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const sender = msg.from.username || msg.from.first_name;
  const query = match[1];

  try {
    // Langsung proses tanpa cek verifikasi
    await bot.sendMessage(chatId, "⏳ Lagi nyari lagu di Spotify, tunggu bentar bre...");

    const api = `https://api.nekolabs.my.id/downloader/spotify/play/v1?q=${encodeURIComponent(query)}`;
    const { data } = await axios.get(api);

    if (!data.success || !data.result) {
      return bot.sendMessage(chatId, "❌ Gagal ambil data lagu dari Spotify!");
    }

    const { metadata, downloadUrl } = data.result;
    const { title, artist, cover, duration, album } = metadata;

    // Format durasi dari detik ke menit:detik
    const formatDuration = (seconds) => {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    const formattedDuration = duration ? formatDuration(duration) : "-";
    
    // Buat caption dengan HTML yang lebih menarik
    const caption = `
🎵 <b>${title || "Unknown Title"}</b>

👤 <b>Artis:</b> ${artist || "Unknown Artist"}
📀 <b>Album:</b> ${album || "Unknown Album"}
⏱️ <b>Durasi:</b> ${formattedDuration}

🔽 <i>Audio sedang dikirim...</i>

📤 Request by: ${sender}
`;

    // Gunakan template HTML yang lebih menarik
    const htmlCaption = `
<b>🎵 NOW PLAYING</b>
━━━━━━━━━━━━━━━

<b>📌 Judul:</b> ${title || "Unknown Title"}
<b>🎤 Artis:</b> ${artist || "Unknown Artist"}
<b>💿 Album:</b> ${album || "Unknown Album"}
<b>⏰ Durasi:</b> ${formattedDuration}

━━━━━━━━━━━━━━━
<code>⬇️ Downloading audio...</code>
`;

    // Kirim thumbnail dengan template yang lebih menarik
    await bot.sendPhoto(chatId, cover, {
      caption: htmlCaption,
      parse_mode: "HTML",
    });

    // Kirim audio dengan thumbnail custom
    await bot.sendAudio(chatId, downloadUrl, {
      title: title || "Unknown Title",
      performer: artist || "Unknown Artist",
      thumb: cover, // Gunakan cover sebagai thumbnail audio
      caption: `✅ <b>${title}</b>\n👤 ${artist}\n\n🎵 Spotify Downloader`,
      parse_mode: "HTML",
    });

  } catch (err) {
    console.error("Play Error:", err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat memutar lagu bre.");
  }
});

// === /ping ===
bot.onText(/^\/ping$/i, async (msg) => {
  if (!(await cekAkses("owner", msg))) return;
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const username = msg.from.first_name || "User";
  try {
    const startTime = Date.now();
    
    const pingMsg = await bot.sendMessage(chatId, `
<blockquote>🏓 </blockquote>
➥ <b>Status:</b> Sedang menghitung ping...`, { 
      parse_mode: "HTML" 
    });
    
    const botPing = Date.now() - startTime;

    const uptimeMs = Date.now() - BOT_START_TIME;
    const uptime = formatUptime(Math.floor(uptimeMs / 1000));
    const totalMem = os.totalmem() / (1024 ** 3);
    const freeMem = os.freemem() / (1024 ** 3);
    const usedMem = totalMem - freeMem;
    const memoryUsage = process.memoryUsage();
    const cpuModel = os.cpus()[0].model;
    const cpuCores = os.cpus().length;

    const teks = `
<blockquote>🖥️ </blockquote>

⚡ <b>PERFORMANCE</b>
➥ <b>Bot Ping:</b> <code>${botPing}ms</code>
➥ <b>Uptime:</b> <code>${uptime}</code>

🔧 <b>HARDWARE</b>
➥ <b>CPU:</b> <code>${cpuModel}</code>
➥ <b>Cores:</b> <code>${cpuCores} Core</code>
➥ <b>RAM:</b> <code>${usedMem.toFixed(2)}GB / ${totalMem.toFixed(2)}GB</code>
➥ <b>Memory Usage:</b> <code>${(memoryUsage.rss / 1024 / 1024).toFixed(2)}MB</code>

📊 <b>STATISTIK</b>
➥ <b>Total Users:</b> <code>${loadData().users?.length || 0}</code>
➥ <b>Total Groups:</b> <code>${loadData().groups?.length || 0}</code>
`;

    await bot.editMessageText(teks, {
      chat_id: chatId,
      message_id: pingMsg.message_id,
      parse_mode: 'HTML'
    });

  } catch (err) {
    console.error("❌ Error di /ping:", err);
    bot.sendMessage(chatId, `
<blockquote>❌ </blockquote>
➥ <b>Status:</b> Terjadi kesalahan saat membaca informasi sistem
➥ <b>Error:</b> <code>${err.message}</code>`, { parse_mode: 'HTML' });
  }
});

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  
  const parts = [];
  if (d > 0) parts.push(`${d} hari`);
  if (h > 0) parts.push(`${h} jam`);
  if (m > 0) parts.push(`${m} menit`);
  if (s > 0) parts.push(`${s} detik`);
  
  return parts.join(', ');
}