module.exports = {
  BOT_TOKEN: '8328175307:AAH9kjgrccN3t6Tw3pd6wwJDQ7f0i5w3Hc8',
  OWNER_IDS: ['2010120067'],
  CHANNEL_USERNAME: '@lolhdz',
  DEVELOPER: '@myhadz',
  MENU_IMAGES: [
    'https://files.catbox.moe/1ztypk.jpg'
  ],

  PAYMENT_SETTINGS: {
    MIN_DEPOSIT: 1000,
    ADMIN_FEE: {
      FIXED: 200,
      PERCENTAGE: 2
    },
    QRIS_DATA: {
      image_url: 'https://files.catbox.moe/2t6rl7.jpeg',
      note: 'Scan QRIS di atas dan kirim nominal sesuai total pembayaran.'
    }
  }
};